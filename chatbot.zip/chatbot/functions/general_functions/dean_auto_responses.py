def generateDoesntUnderstandResponse():
    return 'Hmm... saya tidak mengerti apa maksudmu...'

def generateDataNotFoundResponse():
    return 'Maaf, saya tidak memiliki informasi yang bisa saya gunakan untuk menjawab pertanyaan anda'

def generateClassifiedResponse():
    return 'Maaf, saya tidak diizinkan untuk menjawab pertanyaan tersebut'