from dependencies import *

class DateTime:
    def __init__(self):
        self.datetime = datetime.now()

    def getCurrentDateTime(self):
        return self.datetime

    def getCurrentDate(self):
        return self.datetime.strftime('%Y-%m-%d')

    def getCurrentTime(self):
        return self.datetime.strftime("%H:%M:%S")

    def getCurrentYear(self):
        return self.datetime.year

    def getCurrentMonth(self):
        return self.datetime.month

    def getCurrentDay(self):
        return self.datetime.day
    
    def getDatePlusMinusXTime(self, date, xtime, xtype, plus):
        date = datetime.strptime(date, '%Y-%m-%d') 

        if xtype == 1:  #day
            relativedeltacondition = relativedelta(days=xtime)
        elif xtype == 2:    #month
            relativedeltacondition = relativedelta(months=xtime)
        
        if plus is True:    #go forward
            date_minus_one_month = date + relativedeltacondition
        else:   #go backward
            date_minus_one_month = date - relativedeltacondition

        return date_minus_one_month.strftime('%Y-%m-%d')