from datetime import datetime

def generatePythonLog(npk, tag, userinput, response):
    currentdate = datetime.now().strftime('%A, %d %B %Y')
    currenttime = datetime.now().strftime('%H:%M:%S')

    print('\n\n\n=======================================================================')
    
    print('\nCurrent datetime:', currentdate, currenttime)
    print("User's NPK:", npk)
    print('Used tag:', tag)
    print('\nUser:', userinput)
    print('Dean:', response)

    print("\n=========================================================================\n")