from dependencies import *

def seeIntentsTags():
    print('\n\n')
    intents_df = pd.json_normalize(intents_json['intents'])
    data = intents_df.explode('patterns')
    print(data.tag.value_counts())

def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
    return sentence_words

def bag_of_words(sentence, words):
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words)
    for w in sentence_words:
        for i, word in enumerate(words):
            if word == w:
                bag[i] = 1
    return np.array(bag)

def predict_class(sentence, model, words, classes):
    bow = bag_of_words(sentence, words)
    res = model.predict(np.array([bow]))[0]
    MINIMUM_ERROR_THRESHOLD = 0.85 #0.75

    results = [[i, r] for i, r in enumerate(res) if r > MINIMUM_ERROR_THRESHOLD]
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []

    for r in results:
        return_list.append({'intent': classes[r[0]], 'probability': str(r[1])})



    fullresults = [[i, r] for i, r in enumerate(res)]
    fullresults.sort(key=lambda x: x[1], reverse=True)
    full_return_list = []

    for r in fullresults:
        full_return_list.append({'intent': classes[r[0]], 'probability': str(r[1])})

    if len(return_list) == 0:
        return 0, full_return_list
    return return_list, full_return_list

def get_tag(intents_list, intents_json):
    tag = intents_list[0]['intent']

    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if i['tag'] == tag:
            target_intention = i['tag']
            break
    return target_intention
