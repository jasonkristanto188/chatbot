from functions.getTag.get_tag_functions import *

def getTag(userinput, words_jsonpath, classes_jsonpath, intents_jsonpath, model_path):
    with open(words_jsonpath, 'r') as f:
        words = json.load(f)

    with open(classes_jsonpath, 'r') as f:
        classes = json.load(f)
        
    intents_json = json.loads(open(intents_jsonpath).read())
    model = load_model(model_path)

    ints, fullints = predict_class(userinput, model, words, classes)    #chatbotfunctions.py

    tag = None
    if ints != 0:
        tag = get_tag(ints, intents_json)   #chatbotfunctions.py
        print('Calculated tag:', tag)
    
    return tag