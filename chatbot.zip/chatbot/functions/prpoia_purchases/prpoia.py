from functions.prpoia_purchases.GA_functions import *

def generatePOstatusResponse(userinput):
    response = None

    POnum, PRnum, IAnum = getPOPRIAnum(userinput)

    if POnum is not None:
        df = getGAdata(POnum, 1)

        postatus = list(set(df['PO_Pos_Status'].values.tolist()))
        response = postatus[0]

    elif PRnum is not None:
        df = getGAdata(PRnum, 2)
        if len(df) == 0:
            return 'Nomor PR ' + PRnum + ' belum ada POnya'
        
        ponumbers = list(set(df['PO_No'].values.tolist()))
        statusset = set(df['PO_Pos_Status'].values.tolist())

        if len(statusset) == 1:
            response = statusset.pop()
        elif len(statusset) > 1:
            response = ''
            for num in ponumbers:
                tempdf = df[df['PO_No'] == num]
                sap_po_list = list(set(tempdf['SAP_PO_No'].values.tolist()))
                postatus = list(set(tempdf['PO_Pos_Status'].values.tolist()))

                if sap_po_list[0] is None or sap_po_list[0] == '':
                    response += str(num) + ': ' + postatus[0] + '\n'
                else:
                    response += str(sap_po_list[0]) + ': ' + postatus[0] + '\n'
        
    elif IAnum is not None:
        df = getGAdata(IAnum, 3)
        if len(df) == 0:
            return 'Nomor IA ' + IAnum + ' belum ada POnya'
        
        ponumbers = list(set(df['PO_No'].values.tolist()))
        statusset = set(df['PO_Pos_Status'].values.tolist())

        if len(statusset) == 1:
            response = statusset.pop()
        elif len(statusset) > 1:
            response = ''
            print('\ninside elif elif....\n')

            for num in ponumbers:
                tempdf = df[df['PO_No'] == num]
                sap_po_list = list(set(tempdf['SAP_PO_No'].values.tolist()))
                print(sap_po_list)

                postatus = list(set(tempdf['PO_Pos_Status'].values.tolist()))
                
                if sap_po_list[0] is None or sap_po_list[0] == '':
                    response += str(num) + ': ' + postatus[0] + '\n'
                else:
                    print('\nInside one more elif...\n')
                    response += str(sap_po_list[0]) + ': ' + postatus[0] + '\n'

    if response is None:
        response = generateDataNotFoundResponse()
        
    return response

def generateIAPRPOresponse(userinput):
    response = None

    breakinput = userinput.split()

    POnum, PRnum, IAnum = getPOPRIAnum(userinput)
    
    selectType = None
    if PRnum is not None and POnum is None:
        print('PR num detected')
        selectType = 'pr'
    elif IAnum is not None and POnum is None:
        print('IA num detected')
        selectType = 'ia'
    elif POnum is not None:
        print('PO num detected')
        for x in breakinput:
            if x == 'pr' or x == 'prnya':
                selectType = 'pr'
            elif x == 'ia' or x == 'ianya':
                selectType = 'ia'

    print('\nSelect type:', selectType, '\n')

    if selectType == 'ia':
        if POnum is not None:
            df = getIAdata()
            IAnumlist = df['IA_No'][df['SAP_PO_No'] == POnum].values.tolist()

            #Each PO only has one IA / PR number
            response = 'Nomor IA untuk nomor PO ' + str(POnum) + ' adalah ' + IAnumlist[0]
        else:
            df = getGAdata(IAnum, 3)
            POnumlist = df['SAP_PO_No'].values.tolist()
            POnumlist = set(POnumlist)
            
            if len(POnumlist) > 0:
                questiontype, questionword = getQuestionType(userinput)
                if questiontype == 6 or questiontype == None:
                    response = ''
                    if questiontype == None:
                        response += 'Sudah ada. '
                    
                    if len(POnumlist) == 1:
                        response += 'Untuk IA ' + IAnum + ', nomor POnya ' + str(POnumlist.pop())
                    elif len(POnumlist) > 1:
                        POnumlist = set(POnumlist)
                        response += 'Untuk IA ' + IAnum + ', berikut adalah nomor-nomor POnya:\n'
                        for num in POnumlist:
                            if num is not None:
                                response += num + '\n'

    elif selectType == 'pr':
        if POnum is not None:
            df = getPRdata()
            PRnumlist = df['PR_No'][df['SAP_PO_No'] == POnum].values.tolist()

            #Each PO only has one IA / PR number
            response = 'Nomor PR untuk nomor PO ' + str(POnum) + ' adalah ' + PRnumlist[0]
        else:
            df = getGAdata(PRnum, 2)
            POnumlist = df['SAP_PO_No'].values.tolist()

            if len(POnumlist) > 0:
                POnumlist = set(POnumlist)

                if len(POnumlist) == 0:
                    response = 'Nomor PR ' + str(PRnum) + ' belum ada POnya'
                else:
                    questiontype, questionword = getQuestionType(userinput)
                    if questiontype == 6 or questiontype == None:
                        response = ''
                        if questiontype == None:
                            response += 'Sudah ada. '
                        
                        if len(POnumlist) == 1:
                            response += 'Untuk PR ' + PRnum + ', nomor POnya ' + str(POnumlist.pop())
                        elif len(POnumlist) > 1:
                            POnumlist = set(POnumlist)
                            response += 'Untuk PR ' + PRnum + ', berikut adalah nomor-nomor POnya:\n'
                            for num in POnumlist:
                                if num is not None:
                                    response += num + '\n'

    if response is None:
        if selectType == 'ia':
            response = 'Nomor IA ' + str(IAnum) + ' belum ada POnya'
        elif selectType == 'pr':
            response = 'Nomor PR ' + str(PRnum) + ' belum ada POnya'
    
    return response
