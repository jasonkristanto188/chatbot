from functions.prpoia_purchases.GA_functions import *

def generateGAMaterialResponse(userinput):
    response = generateDataNotFoundResponse()
    POnum, PRnum, IAnum = getPOPRIAnum(userinput)

    if POnum is None and PRnum is None and IAnum is None:
        GAmatnumFound = False
        GAmatnum = 0
        breakinput = userinput.split()
        for x in breakinput:
            if re.match('^6[0-9]*$', x) or re.match('^0.+[6]*$', x):
                GAmatnum = str(x)
                GAmatnumFound = True
                print('\nGA material number found:', GAmatnum, '\n')
        
        if GAmatnumFound:
            df = getMaterialPrice(GAmatnum, 2)
            if df.shape[0] == 0:
                response = generateDataNotFoundResponse()
            else:
                materialnameset = list(set(df['Material_Name'].values.tolist()))
                if len(materialnameset) == 1:
                    response =  GAmatnum + ' itu ' + materialnameset[0]
                else:
                    response = 'Berikut adalah list material ' + GAmatnum + ':\n'
                    for mat in materialnameset:
                        response += mat + '\n'
            
        else:   #searching material name...
            print('\nUnfortunately, there is no PO/PR/IA/material number detected...\n')

            removewords = ['onesystem', 'one system', 'material']
            for x in removewords:
                userinput = userinput.replace(x, '')
            print('\nEdited userinput:', userinput, '\n')

            translated = googleTranslate(userinput, 'id', 'en')
            # taglist = ['NN', 'NNS']
            # usefulwords = partOfSpeechTagging(translated, taglist)

            taglist = ['NOUN', 'PROPN', 'NUM']
            usefulwords = spacy_Tag(translated, taglist)



            targetwords = getTargetWords(userinput, usefulwords)
            
            if len(targetwords.split()) > 0:
                df = getMaterialPrice(targetwords, 1)
                if len(df) > 0:
                    targetobject = most_common(df['Material_Name'].values.tolist())
                    targetobject = str(targetobject).strip()

                    response = targetwords + ' ada di onesystem.\n'
                    response += 'Model yang paling banyak dibeli adalah ' + targetobject 
                    response += '\nBerikut adalah list material numbersnya:\n'
                    for item in set(df['Material_No'].values.tolist()):
                        if item != ' ':
                            response += item + '\n'
                else:
                    response = targetwords + ' tidak ada di onesystem'

    else:
        if POnum is not None:
            print('\nPO num found', POnum, '\n')
            df = getGAdata(POnum, 1)
        elif PRnum is not None:
            print('\nPR num found', PRnum, '\n')
            df = getGAdata(PRnum, 2)
        elif IAnum is not None:
            print('\nIA num found:', IAnum, '\n')
            df = getGAdata(IAnum, 3)
        else:
            materialNum = ''

            breakinput = userinput.split()
            for x in breakinput:
                if x.isdigit():
                    if x.startswith('6'):
                        materialNum += '00000000'
                    materialNum += x
            
            df = getPOMaterialdata(materialNum)

        if df.shape[0] == 0:
            response += '\nBerikut adalah contoh-contoh command yang kumengerti:\n'
            response += '"status PO XXXXXXXXXX", \n"material 6XXXXXXXXX itu apa", \n"berapa harga rata rata material 6XXXXXXXXX"'
            response += '\nUntuk saat ini, saya hanya bisa menjawab material-material GA (nomor material dimulai dengan angka 6)'
        else:
            print('dataframe check:')
            print(df)
            print(df.columns)

            if IAnum is not None or POnum is not None or PRnum is not None:
                MaterialNameList = list(set(df['Material_Name'].values.tolist()))

                if len(MaterialNameList) == 1:
                    response = MaterialNameList[0] + '\n'
                else:
                    response = 'Berikut adalah list material-materialnya:\n'
                    for material in MaterialNameList:
                        response += material + '\n'
    
    return response

def avgHargamaterial(userinput):
    response = generateDataNotFoundResponse()

    breakinput = userinput.split()
    gaMaterialNum = None

    for word in breakinput:
        if word.isdigit() and word[0] == '6' and len(word) == 10:
            gaMaterialNum = int(word)
    
    if gaMaterialNum is not None:
        df = getMaterialPrice(gaMaterialNum, 2)

        if len(df) > 0:
            print(df)

            avgPrice = df['Price'].mean()
            formatted_num = format(avgPrice, ',.1f').replace(',', 'X').replace('.', ',').replace('X', '.')
            response = 'Harga rata-rata material ' + str(gaMaterialNum) + ': Rp ' + formatted_num
    else:
        translated = googleTranslate(userinput, 'id', 'en')

        taglist = ['NOUN', 'PROPN', 'NUM']
        temp = spacy_Tag(translated, taglist).lower()
        usefulwords = temp.replace('price', '')
        print('Useful english string:', usefulwords)

        targetwords = getTargetWords(userinput, usefulwords)
        if len(targetwords.split()) > 0:
            df = getMaterialPrice(targetwords, 1)

            if len(df) > 0:
                print(df)

                avgPrice = df['Price'].mean()
                formatted_num = format(avgPrice, ',.1f').replace(',', 'X').replace('.', ',').replace('X', '.')
                response = 'Harga rata-rata ' + targetwords + ': Rp ' + formatted_num
    
    return response


def generateDivPurchaseResponse(userinput):
    if userinput[-1] == '?':
        userinput = userinput[:-1]
    print('\nUser input:', userinput)

    response = generateDataNotFoundResponse()

    translated = googleTranslate(userinput, 'id', 'en')
    
    taglist = ['NOUN', 'PROPN', 'NUM']
    spok = spacy_Tag(translated, taglist)
    
    temp = spok.split()
    removewordsset = {'div', 'divisi', 'division', 'beli', 'pembelian', 'membeli'}
    for word in removewordsset:
        if word in temp:
            spok = spok.replace(word, '')
    freshresult = spok.lower().strip()
    print('\nFresh result:', freshresult)
    
    targetwords = getTargetWords(userinput, freshresult)

    additionalquery = " where Material_Name like '%" + targetwords + "%'"
    df = getMaterialPurchases(additionalquery)

    #if no data found, maybe there is a misarrangement of the target object's name in the userinput :v
    #e.g. say u wanna search "tab samsung galaxy", but the db only has "samsung galaxy tab", which is p much the same thing :v
    if len(df) == 0:
        splitusefulwords = targetwords.split()
        
        if len(splitusefulwords) > 1:
            combinations = list(itertools.permutations(splitusefulwords))
            for combination in combinations:
                targetwords = ' '.join(combination)

                additionalquery = " where Material_Name like '%" + targetwords + "%'"
                print('Retrying with:', targetwords, '\n')
                df = getMaterialPurchases(additionalquery)

                if len(df) > 0:
                    break

    if len(df) > 0:
        print(df[['Material_Name', 'Div_Name']])
        response = targetwords + ' paling sering dibeli oleh divisi ' + most_common(df['Div_Name'])

    return response

def generateSelfPurchaseResponse(userinput, npk):

    questiontype, questionword = getQuestionType(userinput)
    userinput = removeQuestionWords(userinput)

    breakinput = userinput.split()

    #check if user asks "from month x to month y"
    rangequestion = False
    for word in rangewords:
        if word in breakinput:
            rangequestion = True
            break

    

    #get all months mentioned in userinput
    monthname = []
    monthfound = []
    
    for i, month in enumerate(monthnamelist):
        if month.lower() in breakinput:
            monthname.append(month)
            monthfound.append((i + 1) % 12)
            breakinput.remove(month.lower())
    
    filtered_string = " ".join(breakinput)
    


    #get user's purchases
    userdata = getdata_user(npk)

    if userdata.shape[0] == 0:
        return generateDataNotFoundResponse()

    name = userdata['name'].values[0]   #get user's name
    namesdf = getGANames()
    namelist = namesdf['U_PIC_Name'].values.tolist()

    nametarget = ''
    
    currentHighScore = 0
    for name2 in namelist:
        jarowrinkler_similarity = textdistance.jaro_winkler.normalized_similarity(name.lower(), name2.lower())
        if jarowrinkler_similarity > 0.8:
            if jarowrinkler_similarity > currentHighScore:
                currentHighScore = jarowrinkler_similarity
                nametarget = name2
    print('\nName Target:', nametarget)

    additionalquery = f" where U_PIC_Name like '{nametarget}'"
    df = getMaterialPurchases(additionalquery)
    df = df[df['U_PIC_Name'] == nametarget]



    #generate the response
    response = 'you are asking about self purchases'

    if df.shape[0] == 0:
        print('No data found')
        return response
    else:
        print('data found')
        current_year = datetime.datetime.now().year

        df['Req_Date'] = df['Req_Date'].apply(lambda x: pd.Timestamp(x))
        df['IA_Date'] = df['IA_Date'].apply(lambda x: pd.Timestamp(x))
        # print(df[['Req_Date', 'IA_Date']])

        materiallist = []
        prev_index = 0
        for index2, month in enumerate(monthfound):
            for index, row in df.iterrows():
                if pd.isnull(row['Req_Date']):
                    rowyear = row['IA_Date'].year
                    rowmonth = row['IA_Date'].month
                else:
                    rowyear = row['Req_Date'].year
                    rowmonth = row['Req_Date'].month

                if rangequestion is False:
                    if monthfound[index2] == rowmonth and current_year == rowyear:
                        materiallist.append(row['Material_Name'])
                else:
                    if index2 == 0 and monthfound[index2] == rowmonth and current_year == rowyear:
                        materiallist.append(row['Material_Name'])
                    elif (monthfound[index2] >= rowmonth and monthfound[prev_index] < rowmonth) and current_year == rowyear:
                        materiallist.append(row['Material_Name'])
            prev_index = index2

        if len(materiallist) == 0:
            if rangequestion is False:
                response = 'Anda tidak melakukan pembelian di bulan '
                for month in monthname:
                    response += month
                    if len(monthname) > 1:
                        response += ', '
            else:
                response = 'Anda tidak melakukan pembelian dari bulan ' + monthname[0] + ' sampai ' + monthname[1]
        elif len(materiallist) == 1:
            if questiontype == 0: #apa
                response = materiallist[0]
            elif questiontype == 6: #berapa
                response = 1
        else: 
            counter = Counter(materiallist)

            # Sort by frequency
            sorted_items = sorted(counter.items(), key=lambda x: (-x[1], x[0]))    

            if questiontype == 0: #apa
                response = 'Berikut adalah pembelian anda:\n'
                for item in sorted_items:
                    response += str(item[1]) + ' ' + item[0] + '\n'
                      
            elif questiontype == 6: #berapa
                count = 0
                for item in sorted_items:
                    count += item[1]
                
                response = 'Anda telah melakukan pembelian sebanyak ' + str(count) + ' kali\n'
        return response 
