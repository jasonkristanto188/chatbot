from dependencies import * 
from functions.general_functions.dean_auto_responses import *

def most_common(lst):
    data = Counter(lst)
    return data.most_common(1)[0][0]

def getTargetWords(userinput, spok):
    spok = spok.lower().strip()

    #check if words in fresh result are found in userinput
    finalwords = []
    for word2 in spok.split():
        if word2 in userinput.split():
            finalwords.append(word2)
        elif word2[:-1] in userinput.split():
            finalwords.append(word2[:-1])
    
    usefulwords = ' '.join(finalwords)

    #if not found, try "retranslating" it to indo
    if len(finalwords) == 0:
        breakinput = userinput.split()
        print('spok[:-1]:', spok[:-1])

        for x in breakinput:
            print('x:', x)            
            print('x translated:', googleTranslate(x, 'id', 'en'), '\n')
            if googleTranslate(x, 'id', 'en') == spok or googleTranslate(x, 'id', 'en') == spok[:-1]:
                finalwords.append(x)
        
        usefulwords = ' '.join(finalwords)
        breakinput = usefulwords.split()
        if len(breakinput) == 0:
            print('No target word found...')
            targetwords = generateDataNotFoundResponse()
    
    targetwords = usefulwords.strip()
    print('Target words:', targetwords)
    return targetwords

def getPOPRIAnum(userinput):
    POnum = None
    PRnum = None
    IAnum = None
    
    breakinput = userinput.split()
    for x in breakinput:
        if x.startswith('4'):
            POnum = x
        elif re.match('^g[0-9]+$', x):
            PRnum = x.upper()
        elif x.startswith('.'):
            if IAnum is not None:
                IAnum += ' ' + x.upper()
        else:
            for y in IAopenings:
                if x.startswith(y):
                # if y.lower() in x:
                    IAnum = x.upper()
                    break
    
    return POnum, PRnum, IAnum

def getMaterialPurchases(additionalquery):
    query = """
    select distinct Purch_Req, IA_No, PO_No, SAP_PO_No, a.Material_Name, a.Material_No, 
        Req_Date, IA_Date, U_PIC_Name, Div_Name 
    from (
        select Purch_Req, c.IA_No, PO_No, SAP_PO_No, a.Material_Name, a.Material_No, 
            Req_Date, Created_Date as IA_Date, Created, Created_By
        from [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO_Detail a 
            LEFT JOIN [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PR b on a.PR_No = b.Purch_Req
            LEFT JOIN [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_IA c on a.IA_No = c.IA_No
    ) a INNER JOIN (
        SELECT U_PIC_ID
            ,U_PIC_Name
            ,b.DIV_ID
            ,c.Div_Name
            ,U_PIC_Email1 
            ,DIV_OPEX
        FROM [{OneSystem_cred['server']}].[eProcLiveNew].[dbo].[T_Master_User_PIC] b 
            JOIN [{OneSystem_cred['server']}].[eProcLiveNew].[dbo].[T_Master_Division] c ON b.Div_ID = c.Div_ID
    ) d on d.U_PIC_ID = COALESCE(a.Created, a.Created_By)
    """ 
    finalquery = query + additionalquery

    df = cx.read_sql(conn=WeCare_conn, query=finalquery)
    return df

def getPOMaterialdata(materialNum):
    query = f"""
    select distinct cast(a.SAP_PO_No as varchar) as SAP_PO_No, a.PO_No, a.PR_No, a.IA_No
        , a.Material_No, Material_Name, Qty, a.Un, Price, PPN, PO_Date, b.PO_delivdate
        , CASE
            WHEN  c.SAP_CONFIRM = 'X'  THEN 'PO ALREADY GR'
            WHEN  b.Signed = '1' THEN 'PO UNDER SUPPLIER' ELSE 'PO UNDER GA'
        END as PO_Pos_Status
    from [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO_Detail a
        left join [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO b on a.PO_No = b.PO_No
        left join [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_GRGI c 
            on a.SAP_PO_No = c.SAP_PO_NO and a.Material_No = c.MATERIAL_NO and b.Vendor_No = c.VENDOR_CODE
    where CANCEL_GR_ID is NULL and a.Material_No = '{materialNum}' order by SAP_PO_No, Material_Name
    """
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df

def getGAdata(num, type):
    if type == 1: #PO
        colName = 'a.SAP_PO_No'
    elif type == 2: #PR
        colName = 'PR_No'
    elif type == 3: #IA
        colName = 'IA_No'
    
    query = f"""
    select distinct cast(a.SAP_PO_No as varchar) as SAP_PO_No, a.PO_No, a.PR_No, a.IA_No
        , a.Material_No, Material_Name, Qty, a.Un, Price, PPN, PO_Date, b.PO_delivdate
        , CASE
            WHEN  c.SAP_CONFIRM = 'X'  THEN 'PO ALREADY GR'
            WHEN  b.Signed = '1' THEN 'PO UNDER SUPPLIER' ELSE 'PO UNDER GA'
        END as PO_Pos_Status
    from [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO_Detail a
        left join [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO b on a.PO_No = b.PO_No
        left join [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_GRGI c 
            on a.SAP_PO_No = c.SAP_PO_NO and a.Material_No = c.MATERIAL_NO and b.Vendor_No = c.VENDOR_CODE
    where CANCEL_GR_ID is NULL and {colName} = '{num}'
    """
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df

def getIAdata():
    query = """
    select IA_Detail_Description, a.IA_No, Created_Date, Created_By as IA_Created_By, IA_Subject, validity_date, Approved_Date, SAP_PO_No
    from eProcLiveNew.dbo.T_IA a left join eProcLiveNew.dbo.T_PO_Detail b on a.IA_No = b.IA_No 
    join eProcLiveNew.dbo.T_IA_Detail c on a.IA_No = c.IA_No 
    """
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df

def getPRdata():
    query = """
    select PR_No, Material, Short_Text, Quantity, b.Un, Req_Date, SAP_PO_No
    from [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PR a 
        left join [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO_Detail b 
            on a.Purch_Req = b.PR_No and a.Material = b.Material_No
    order by PR_No, Material, Short_Text, Req_Date
    """
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df

IAopenings = ['ho/', 'p1/', 'p2/', 'p3/', 'p4/', 'p5/']

def getMaterialPrice(mat, type):
    query = f"select distinct Material_Name, Material_No, Price, PPN from [{OneSystem_cred['server']}].eProcLiveNew.dbo.T_PO_Detail "

    if type == 1: #name
        query += f"where Material_Name like '%{mat}%'"
    elif type == 2: #no
        query += f"where Material_No like '%{mat}%'"
    
    query += " order by Price"
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df

def getGANames():
    query = "select distinct U_PIC_Name, U_PIC_ID from [{OneSystem_cred['server']}].[eProcLiveNew].[dbo].[T_Master_User_PIC]"
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df
