from dependencies import *

def getDateBasedOnDayname(userinput):
    breakinput = userinput.split()

    daynames = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu']
    dayindex = None
    for word in breakinput:
        if word.lower() in daynames:
            dayindex = daynames.index(word.lower())
    
    if dayindex is None:
        return None
    else:
        currentdate = datetime.now()
        days_ahead = dayindex - currentdate.weekday() + 7
        if days_ahead >= 7:
            days_ahead -= 7

        next_targetday = currentdate + timedelta(days=days_ahead)
        return next_targetday.strftime('%Y-%m-%d')

def getDateOrthodox(userinput):
    if 'hari ini' in userinput.lower():
        return datetime.now().strftime('%Y-%m-%d')
    elif 'besok' in userinput.lower():
        currentdatetime = datetime.now() + timedelta(days=1)
        return currentdatetime.strftime('%Y-%m-%d')
    elif 'lusa' in userinput.lower():
        currentdatetime = datetime.now() + timedelta(days=2)
        return currentdatetime.strftime('%Y-%m-%d')
    elif 'minggu depan' in userinput.lower():
        currentdatetime = datetime.now() + timedelta(days=7)
        return currentdatetime.strftime('%Y-%m-%d')
    elif 'kemarin' in userinput.lower():
        currentdatetime = datetime.now() - timedelta(days=1)
        return currentdatetime.strftime('%Y-%m-%d')
    else:
        return None

def getDate(userinput):
    targetdate = None

    #try to get date based on daymonthyear
    if targetdate is None:
        targetdate = getDateOrthodox(userinput)

    #try to get date based on day
    if targetdate is None:
        targetdate = getDateBasedOnDayname(userinput)
    
    return targetdate
    

def getDateBasedOnHour(userinput):
    breakinput = userinput.split()

    hour = None
    for word in breakinput:
        if word.lower() in ['jam', 'pukul', 'waktu', 'jem']:
            hourindex = breakinput.index(word.lower()) + 1
            hour = breakinput[hourindex]

            if len(hour) <= 2:
                datetime_hour = datetime.strptime(hour, '%H')
            elif len(hour) <= 5:
                datetime_hour = datetime.strptime(hour, f'%H{hour[2]}%M')
            elif len(hour) == 8:
                datetime_hour = datetime.strptime(hour, f'%H{hour[2]}%M{hour[5]}%S')
            
            potential_time_desc_index = breakinput.index(word.lower()) + 2
            if potential_time_desc_index < len(breakinput):
                if breakinput[potential_time_desc_index].lower() in ['siang', 'pm', 'pm.', 'p.m.']:
                    datetime_hour += timedelta(hours=12)
            
            print('\nhour:', datetime_hour)
            
            if len(hour) <= 2:
                return datetime_hour.strftime('%H')
            elif len(hour) == 5:
                return datetime_hour.strftime('%H:%M')
            elif len(hour) == 8:
                return datetime_hour.strftime('%H:%M:%S')


            break
        
    # if hour is not None:
    #     if len(hour) <= 2:
    #         return datetime.strptime(hour, '%H').strftime('%H:%M:%S')
    #     elif len(hour) == 5:
    #         separator = hour[2]
    #         return datetime.strptime(hour, f'%H{separator}%M').strftime('%H:%M:%S')
    #     elif len(hour) == 8:
    #         first_separator = hour[2]
    #         second_separator = hour[5]
    #         return datetime.strptime(hour, f'%H{first_separator}%M{second_separator}%S').strftime('%H:%M:%S')
    # else:
    #     return None

def getDataRuangan(room=None):
    query = '''
    select room_code, capacity, facility, building_info, l.name as location_name
    from [astradaihatsu_wecare].[dbo].[booking_room_masters] m 
	    left join [astradaihatsu_wecare].[dbo].[locations] l on m.location_id = l.id
	    left join [astradaihatsu_wecare].[dbo].[booking_room_master_facilities] f on m.id = f.[booking_room_master_id]
	where l.name = 'Head Office' and is_available = 1
    '''

    if room is not None:
        query += f" and room_code = '{room.upper()}'"

    print('\nfetching master room data...')
    df = cx.read_sql(conn=WeCare_conn, query=query)
    print('data successfully fetched\n')
    return df

def getDataBookingRuangan(room=None, specificdate=None):
    query = f'''
    SELECT [room_code], [npk], [name]
        , [start_booking_date]
        , [start_booking]
        , [end_booking_date]
        , [end_booking]
        , [necessity]
    FROM [astradaihatsu_wecare].[dbo].[booking_room_transactions] t
    right join (
        select room_code, id
        from [astradaihatsu_wecare].[dbo].[booking_room_masters]
        where location_id = 1 and is_available = 1
    ) b
    on t.booking_room_master_id = b.id
    '''

    extraquery = []
    if specificdate is not None:
        extraquery.append(f" start_booking_date <= '{specificdate}' and '{specificdate}' <= end_booking_date ")
    else:
        extraquery.append(f" start_booking_date >= '{datetime.now().strftime('%Y-%m-%d')}' ")
    
    if room is not None:
        extraquery.append(f" room_code = '{room.upper()}' ")
    
    if len(extraquery) > 0:
        query += ' where '
        i = 0
        while i < len(extraquery):
            query += extraquery[i]
            i += 1
            if i < len(extraquery):
                query += ' and '
            
    query += 'order by room_code, start_booking_date, start_booking'
    df = cx.read_sql(conn=WeCare_conn, query=query)
    return df

def getCurrentlyUsedRooms(room):
    #get data for booked rooms
    bookingdf = getDataBookingRuangan(room, datetime.now().strftime('%Y-%m-%d'))
    
    # currentdate = datetime.now().strftime('%Y-%m-%d')
    currenttime = datetime.now().strftime('%H:%M:%S')

    #rooms currently used right now
    # datecondition = bookingdf['start_booking_date'] == currentdate
    timecondition1 = bookingdf['start_booking'] <= currenttime
    timecondition2 = bookingdf['end_booking'] >= currenttime

    # return bookingdf[datecondition & timecondition1 & timecondition2]
    return bookingdf[timecondition1 & timecondition2]

def getAvailableRooms(roomlist, targetroom=None, targetdate=None):
    mainavailabledf = pd.DataFrame()

    if targetroom is not None:
        roomlist = [targetroom]

    for room in roomlist:
        bookedrooms_df = getDataBookingRuangan(room, targetdate)
        # print(bookedrooms_df[['room_code', 'start_booking_date', 'start_booking', 'end_booking']])

        if len(bookedrooms_df) == 0:
            mainlist = []
            for i in range(5):
                date = datetime.now() + timedelta(days=i)
                mainlist.append([room, date.strftime('%Y-%m-%d'), '00:00:00', '23:59:59'])
            
            availabledf = pd.DataFrame(mainlist, columns=['room_code', 'available_booking_date', 'available_start_time', 'available_end_time'])
        else:
            datelist = list(set(bookedrooms_df['start_booking_date'].tolist()))
            datelist.sort()

            for date in datelist:
                tempdf = bookedrooms_df[bookedrooms_df['start_booking_date'] == date].reset_index()
                # print(tempdf[['room_code', 'start_booking_date', 'start_booking', 'end_booking_date', 'end_booking']])
                
                mainlist = []
                for index, row in tempdf.iterrows():
                    if index == 0:
                        if row['start_booking'] != '00:00:00':
                            #first available row
                            start_time = '00:00:00'
                            end_time = datetime.strptime(row['start_booking'], '%H:%M:%S') - timedelta(minutes=1)
                            end_time = end_time.strftime('%H:%M:%S')
                            newrow1 = [row['room_code'], row['start_booking_date'].strftime('%Y-%m-%d'), start_time, end_time]
                            mainlist.append(newrow1)

                            #next available row
                            if len(tempdf) == 1:
                                next_start_time = datetime.strptime(row['end_booking'], '%H:%M:%S') + timedelta(minutes=1)
                                next_start_time = next_start_time.strftime('%H:%M:%S')
                                next_end_time = '23:59:00'

                                newrow2 = [row['room_code'], row['start_booking_date'].strftime('%Y-%m-%d'), next_start_time, next_end_time]
                                mainlist.append(newrow2)
                            
                        else:
                            start_time = datetime.strptime(row['end_booking'], '%H:%M:%S') + timedelta(minutes=1)
                            start_time = start_time.strftime('%H:%M:%S')

                            if len(tempdf) > 1:
                                nextrow = tempdf.iloc[index + 1]
                                end_time = datetime.strptime(nextrow['start_booking'], '%H:%M:%S') - timedelta(minutes=1)
                                end_time = end_time.strftime('%H:%M:%S')
                            else:
                                end_time = '23:59:00'

                            newrow = [row['room_code'], row['start_booking_date'].strftime('%Y-%m-%d'), start_time, end_time]
                            mainlist.append(newrow)

                    else:
                        pastrow = tempdf.iloc[index - 1]
                        start_time = datetime.strptime(pastrow['end_booking'], '%H:%M:%S') + timedelta(minutes=1)
                        start_time = start_time.strftime('%H:%M:%S')
                        end_time = datetime.strptime(row['start_booking'], '%H:%M:%S') - timedelta(minutes=1)
                        end_time = end_time.strftime('%H:%M:%S')

                        if start_time < end_time and row['start_booking_date'] == row['end_booking_date']:
                            newrow = [row['room_code'], row['start_booking_date'].strftime('%Y-%m-%d'), start_time, end_time]
                            mainlist.append(newrow)

                        if index + 1 == len(tempdf):
                            last_start_time = datetime.strptime(row['end_booking'], '%H:%M:%S') + timedelta(minutes=1)
                            last_start_time = last_start_time.strftime('%H:%M:%S')
                            last_end_time = '23:59:00'
                            lastrow = [row['room_code'], row['start_booking_date'].strftime('%Y-%m-%d'), last_start_time, last_end_time]
                            mainlist.append(lastrow)
                
                availabledf = pd.DataFrame(mainlist, columns=['room_code', 'available_booking_date', 'available_start_time', 'available_end_time'])
                del mainlist, tempdf
                
        if len(mainavailabledf) == 0:
            mainavailabledf = availabledf
        else:
            mainavailabledf = pd.concat([mainavailabledf, availabledf], ignore_index=True)
    
        del availabledf
    
    return mainavailabledf
           
#text similarity
def getTarget(filtered_string, data):
    filtered_string = filtered_string.lower()

    maxsimilarity = 0
    accuratetarget = ''
    for target in data:
        # print('Target:', target)
        if filtered_string.lower() == str(target).lower(): #if exact match found
            return 1, target

        jarowrinkler_similarity = textdistance.jaro_winkler.normalized_similarity(filtered_string.lower(), target.lower())
        # cosine_similarity = textdistance.cosine.normalized_similarity(filtered_string.lower(), target.lower())

        if maxsimilarity < jarowrinkler_similarity:
            maxsimilarity = jarowrinkler_similarity
            accuratetarget = target

    return accuratetarget
    # return maxsimilarity, accuratetarget
