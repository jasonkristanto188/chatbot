from functions.booking_ruangan.booking_ruangan_functions import *
from functions.getTag.get_tag import getTag
from functions.general_functions.dean_auto_responses import *

def generateBookingRuanganResponse(userinput):
    #get the inner tag for booking ruangan
    # mainpath = 'model/innermodels/bookingruanganmodel'
    mainpath = 'functions/booking_ruangan/booking_ruangan_model'
    words_jsonpath = f'{mainpath}/words.json'
    classes_jsonpath = f'{mainpath}/classes.json'
    intents_jsonpath = f'{mainpath}/bookingruangan_intents.json'
    model_path = f'{mainpath}/bookingruanganmodel.h5'

    tag = getTag(userinput, words_jsonpath, classes_jsonpath, intents_jsonpath, model_path)
    if tag is None:
        return generateDoesntUnderstandResponse()
    else:
        print(f'inner target: {tag}')



    #get master room data
    #room_code, building_info, location_name, facility 
    masterdf = getDataRuangan() 

    #get room list
    roomlist = list(set(masterdf['room_code'].values.tolist()))
    roomlist.sort()

    #now find out whether user wants to search for a specific room or not
    targetroom = None
    for word in userinput.split(' '):
        if word.upper() in roomlist:
            targetroom = word.upper()
            break
    
    if targetroom is None and 'dealing' in userinput.lower():
        dealingrooms = [item for item in roomlist if 'dealing' in item.lower()]
        targetroom = getTarget(userinput, dealingrooms)
        del dealingrooms
    
    print(f'\nTarget room: {targetroom}\n')


    #check if user asks for a specific day
    # targetworkingdate = getDateBasedOnDayname(userinput)
    targetworkingdate = getDate(userinput)
    if targetworkingdate is not None and targetworkingdate != '':
        print('target working date:', targetworkingdate)
    
    #check if user asks for a specific time
    targetworkingtime = getDateBasedOnHour(userinput)
    if targetworkingtime is not None and targetworkingtime != '':
        print('target working time:', targetworkingtime)

    

    #finally, answer user's query
    if tag == 'is room available':
        if 'saat ini' in userinput.lower():
            #get rooms that you can still book today or in the future
            inuse_df = getCurrentlyUsedRooms(targetroom)
            inuse_rooms = inuse_df['room_code'].values.tolist()

            availablerooms = list(set([item for item in roomlist if item not in inuse_rooms]))
            availablerooms.sort()
            del inuse_df, inuse_rooms
        else:
            #date filter
            if targetworkingdate is not None:
                availabledf = getAvailableRooms(roomlist, targetroom, targetworkingdate)
            else:
                availabledf = getAvailableRooms(roomlist, targetroom, datetime.now().strftime('%Y-%m-%d'))
            
            #time filter
            if targetworkingtime != '':
                timecondition1 = availabledf['available_start_time'] <= targetworkingtime
                timecondition2 = availabledf['available_end_time'] >= targetworkingtime
                availabledf = availabledf[timecondition1 & timecondition2]
                del timecondition1, timecondition2

            availablerooms = list(set(availabledf['room_code'].values.tolist()))
            availablerooms.sort()
            del availabledf

        if len(availablerooms) > 0:
            if targetroom is None:
                if len(availablerooms) == 1: 
                    if 'saat ini' in userinput.lower():
                        return f'Ruangan yang kosong saat ini: {availablerooms[0]}'
                    else:   #hari ini di sini jg
                        return f'Ruangan yang kosong: {availablerooms[0]}'
                else:
                    response = 'Berikut adalah ruangan yang available '
                    if 'saat ini' in userinput.lower():
                        response += 'saat ini'
                    response += ':\n'

                    for room in availablerooms:
                        response += room + '\n'
                    return response
            else:
                if targetroom in availablerooms:
                    return f'Ruangan {targetroom} masih available untuk digunakan'
                else:
                    return f'Ruangan {targetroom} sedang digunakan'
        else:
            return 'Semua ruangan sedang digunakan'
    elif tag == 'when will the room be available':
        #get rooms that you can still book today or in the future
        availabledf = getAvailableRooms(roomlist, targetroom, None)

        if len(availabledf) == 0:
            response = targetroom if targetroom is not None else 'Semua ruangan'
            response += ' fully booked / tidak tersedia'
        else:
            print(availabledf)
            if targetroom is not None:
                response = f'Ruangan {targetroom} tersedia pada waktu berikut:'
                datelist = list(set(availabledf['available_booking_date'].values.tolist()))
                datelist.sort()

                for date in datelist:
                    tempdf = availabledf[availabledf['available_booking_date'] == date]

                    response += f"\n{date}:\n"
                    for index, row, in tempdf.iterrows():
                        response += f"{row['available_start_time']} - {row['available_end_time']}\n"
                    del tempdf
                del datelist
            else:
                response = 'Berikut adalah list ruangan beserta waktu availability mereka:\n'

                for room in roomlist:
                    tempdf = availabledf[availabledf['room_code'] == room]
                    response += f"\n\n{tempdf['room_code'].values.tolist()[0]}\n"

                    datelist = list(set(tempdf['available_booking_date'].values.tolist()))
                    datelist.sort()

                    for date in datelist:
                        tempdf2 = tempdf[tempdf['available_booking_date'] == date]

                        response += f"\n{tempdf2['available_booking_date'].values.tolist()[0]}:\n"

                        for index, row, in tempdf2.iterrows():
                            response += f"{row['available_start_time']} - {row['available_end_time']}\n"
                        del tempdf2

                    del tempdf, datelist
            
        del availabledf
        return response
    elif tag == 'who books the room':
        if targetroom is None:
            return 'ruangan mana yang ingin anda book?'
        else:
            #get currently used rooms
            inuse_df = getCurrentlyUsedRooms(targetroom)
            userlist = inuse_df['name'][inuse_df['room_code'] == targetroom].values.tolist()
            del inuse_df

            if len(userlist) > 0:
                user = userlist[0]
                return f"ruangan {targetroom} sedang dibook oleh {user}"
            else:
                return f"ruangan {targetroom} sedang tidak dibook"
    elif tag == 'room facilities':
        if targetroom is None:
            response = 'Berikut adalah list fasilitas yang ada di ruangan2 ADM:\n'
            
            for room in roomlist:
                tempdf = masterdf[masterdf['room_code'] == room]
                response += f"room: {room}\n"
                for index, row in tempdf.iterrows():
                    response += f"{row['facility']}\n"
                response += f"kapasitas: {row['capacity']} orang\n\n"

                del tempdf
        else:
            response = f'Berikut adalah list fasilitas ruangan {targetroom}:\n'
            targetdf = masterdf[masterdf['room_code'] == targetroom]
            for index, row, in targetdf.iterrows():
                response += f"{row['facility']}\n"
            response += f"kapasitas: {row['capacity']} orang\n\n"
        
        return response
