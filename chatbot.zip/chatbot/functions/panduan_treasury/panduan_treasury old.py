from chatbotfunctions import *
from functions.general_functions.dean_auto_responses import *
import difflib

# mainpath = r"D:\Users\jason.kristanto\PycharmProjects\CondaProjects\chatbot\functions\panduan_treasury"
mainpath = "functions/panduan_treasury"
excelpath = f"{mainpath}/LIST PERTANYAAN FIX.xlsx"
sop_excel_path = f"{mainpath}/SOP files/panduan_SOP.xlsx"

def get_all_data():
    excelfile = pd.ExcelFile(excelpath)
    sheetname_list = excelfile.sheet_names

    maindf = pd.DataFrame()
    for sheetname in sheetname_list:
        df = pd.read_excel(excelpath, sheetname)
        maindf = pd.concat([maindf, df], ignore_index=True)
    
    # additional_df = pd.read_excel(sop_excel_path)
    # maindf = pd.concat([maindf, additional_df], ignore_index=True)
    maindf = maindf[~pd.isna(maindf['Category'])]
    maindf.reset_index(drop=True, inplace=True)
    maindf['Category'] = maindf['Category'].apply(lambda x: x.strip())

    return maindf

def get_category_list():
    df = get_all_data()
    return df['Category'].unique().tolist()

def get_data(userinput):
    category = get_category_list()[int(userinput) - 1]
    maindf = get_all_data()
    df = maindf[maindf['Category'] == category]
    df.reset_index(drop=True, inplace=True)
    return df

def generate_panduan_treasury_questions(userinput):
    df = get_data(userinput)

    questionstr = ''
    for index, row in df.iterrows():
        questionstr += f"<b>{index + 1}. {row['Tag']}</b>"
        questionstr += '\n'

    questionstr += '<b>0. Kembali ke menu sebelumnya</b>\n'
    # questionstr += f'\nTekan angka diatas untuk mendapatkan jawaban yang diinginkan'
    questionstr += '\nAnda juga bisa menulis pertanyaan sendiri'
    questionstr += '\n\nNOTE\n: anda sedang dalam mode treasury\nKembali ke menu sebelumnya untuk keluar juga dari mode treasury'
    return questionstr

def generate_panduan_treasury_answer(userinput, answer):
    df = get_data(userinput)
    if answer >= 1 and answer <= len(df): #1 to len(df)
        return f"{df.loc[int(answer) - 1, 'Tag']}\n\n{df.loc[int(answer) - 1, 'Jawaban']}\n\n"
    else:
        return generateDataNotFoundResponse()

def get_starting_message():
    categorylist = get_category_list()
    response = ''
    count = 1
    for category in categorylist:
        response += f'<b>{count}. {category}</b>\n'
        count += 1
    # response += '\nTekan angka diatas untuk memilih menu'
    
    return response

def generate_panduan_treasury_response(npk, userinput, chainlist):
    # if userinput.lower() == 'treasury':
    if userinput.lower() == 'treasury & banking':
        if get_chainlist_length(npk) > 0:
            clear_chainlist(npk)
        append_to_chainlist(npk, 'panduan treasury') #chain list should have at least 1 value

        response = get_starting_message()  
    else:   
        if userinput.isdigit():
            userinput = int(userinput)
        append_to_chainlist(npk, userinput)

        if len(chainlist) == 2 and (chainlist[-1] > 0 and chainlist[-1] <= len(get_category_list())):
            response = generate_panduan_treasury_questions(chainlist[-1])
        elif len(chainlist) > 2:
            if chainlist[-1] == 0:
                clear_chainlist(npk) 
                append_to_chainlist(npk, 'panduan treasury')
                response = get_starting_message()        
            elif not issubclass(type(chainlist[-1]), str):
                response = generate_panduan_treasury_answer(chainlist[-2], chainlist[-1])
                pop_from_chainlist(npk)
                response += generate_panduan_treasury_questions(chainlist[-1])
            else:
                df = get_data(chainlist[1])

                how_question = False
                for x in ['bagaimana', 'cara', 'gimana', 'prosedur']:
                    if x in chainlist[-1].strip().lower().split():
                        how_question = True
                        break

                max_score = -1
                for index, row in df.iterrows():

                    if max_score == 100:
                        break

                    if how_question and 'definisi' in row['Tag'].lower():
                        continue

                    count = 0
                    for x in chainlist[-1].strip().lower().split():
                        if x in row['Tag'].lower():
                            count += 1

                    if count == len(chainlist[-1].strip().lower().split()):
                        score = 100
                    else:
                        # score = difflib.SequenceMatcher(None, row['Tag'].strip().lower(), chainlist[-1].strip().lower()).ratio()
                        tag_score = difflib.SequenceMatcher(None, row['Tag'].strip().lower(), chainlist[-1].strip().lower()).ratio()

                        max_pertanyaan_score = 0
                        for pertanyaan in row['Pertanyaan'].strip().lower().split('\n'):
                            pertanyaan_score = difflib.SequenceMatcher(None, pertanyaan.strip().lower(), chainlist[-1].strip().lower()).ratio()
                            if max_pertanyaan_score < pertanyaan_score:
                                max_pertanyaan_score = pertanyaan_score
                        
                        score = max_pertanyaan_score if tag_score < max_pertanyaan_score else tag_score
                    
                    if max_score < score:
                        max_score = score
                        response = f'Question: {chainlist[-1]}\n'
                        response += df.loc[index, 'Jawaban']
                       
                        
                pop_from_chainlist(npk)
                response += f'\n\n{generate_panduan_treasury_questions(chainlist[-1])}'
        else:
            response = generateDataNotFoundResponse() 
            clear_chainlist(npk)

    return response
