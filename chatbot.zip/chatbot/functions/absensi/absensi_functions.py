from dependencies import *

absenwords = {'absen', 'absensi', 'clockin', 'clock in', 'clockout', 'clock out'}

#text similarity
def getTarget(filtered_string, data):
    filtered_string = filtered_string.lower()

    maxsimilarity = 0
    accuratetarget = ''
    for target in data:
        if filtered_string.lower() == str(target).lower(): #if exact match found
            return 1, target

        jarowrinkler_similarity = textdistance.jaro_winkler.normalized_similarity(filtered_string.lower(), target.lower())
        # cosine_similarity = textdistance.cosine.normalized_similarity(filtered_string.lower(), target.lower())

        similarity_method = jarowrinkler_similarity
        # similarity_method = cosine_similarity

        if maxsimilarity < similarity_method:
            maxsimilarity = similarity_method
            accuratetarget = target

    return maxsimilarity, accuratetarget
    
def getDailyWorkSchedule(npk):
    cincout_boundaries_query = f"""
    select npk, cast(calendar_date as date) as [Working Date]
        , SUBSTRING(replace(info, 'Pkl ', ''), 1, CHARINDEX('-', replace(info, 'Pkl ', '')) - 1) AS LateStart
        , SUBSTRING(replace(info, 'Pkl ', ''), CHARINDEX('-', replace(info, 'Pkl ', '')) + 1, LEN(replace(info, 'Pkl ', ''))) AS EarlyExit
        , cast(calendar_date as date) as calendar_date 
    from ( 
        select  npk, DWS_ID, calendar_date 
        from [PM3].[dbo].[emp_work_schdl] 
    ) a 
    inner join [PM3].[dbo].[DWS] b on a.DWS_ID = b.DWS_ID 
    where info != 'Free' and npk = '{npk}'
    """
    cincout_boundaries = cx.read_sql(conn=sourceconHRIS, query=cincout_boundaries_query)

    cincout_boundaries['LateStart'] = cincout_boundaries['LateStart'].apply(lambda x: x[:-1] + '1' if x is not None else None)
    cincout_boundaries['LateStart'] = cincout_boundaries['LateStart'].apply(lambda x: pd.to_datetime(x).strftime('%H:%M:%S') if x is not None else None)
    cincout_boundaries['EarlyExit'] = cincout_boundaries['EarlyExit'].apply(lambda x: pd.to_datetime(x).strftime('%H:%M:%S') if x is not None else None)
    cincout_boundaries = cincout_boundaries[['Working Date', 'LateStart', 'EarlyExit']]

    # print('cincoutboundaries:\n', cincout_boundaries)
    return cincout_boundaries

def get_cico(npk):
    absenquery = f"""
    SELECT year(working_date) as [Working Year]
        , month(working_date) as [Working Month]
        , working_date as [Working Date]
        , cast(CI_date as time) as [Clock In]
        , cast(CO_date as time) as [Clock Out] 
    from [PM3].[dbo].[CICO] 
    where npk = {npk} order by working_date
    """
    dataAbsensi = cx.read_sql(conn=sourceconHRIS, query=absenquery)

    cincout_boundaries = getDailyWorkSchedule(npk)
    dataAbsensi = pd.merge(dataAbsensi, cincout_boundaries, on='Working Date')
    return dataAbsensi

def checkAbsenHariIni(npk):
    currentdate = datetime.now().strftime('%Y-%m-%d')
    dataAbsensi = get_cico(npk)
    dataAbsensiHariIni = dataAbsensi[dataAbsensi['Working Date'] == str(currentdate)]

    if dataAbsensiHariIni.shape[0] == 0:
        print('No data found for current date...')
        clockinToday = None
        clockoutToday = None
    else:
        print("Current date's data:")
        print(dataAbsensiHariIni)
        print()
        clockinToday = dataAbsensiHariIni['Clock In'].values[0]
        clockoutToday = dataAbsensiHariIni['Clock Out'].values[0]

    message = ''
    if clockinToday is None:
        message += 'Anda belum clock in hari ini. '
    else:
        if dataAbsensiHariIni['Clock In'].values[0] < dataAbsensiHariIni['LateStart'].values[0]:
            message += 'Hari ini anda tidak terlambat. Tadi sudah clock in pada pukul ' + str(clockinToday) + '. '
        else:
            message += 'Hari ini anda terlambat sebab anda clock in pada ' + str(clockinToday) + '. '

    if clockoutToday is not None:
        message += 'Untuk clock outnya, pada pukul ' + str(clockoutToday) + '. '

    return message

def checkAbsenBulanIni(npk):
    currentmonth = datetime.now().strftime('%m')
    currentdate = datetime.now().strftime('%Y-%m-%d')
    dataAbsensi = get_cico(npk)

    dataAbsensiBulanIni = dataAbsensi[dataAbsensi['Working Month'] == currentmonth]

    if len(dataAbsensiBulanIni) == 0:
        print('tidak ada data absen')
        return ''
    
    print('\nData absensi bulan ini:')
    print(dataAbsensiBulanIni)
    print()

    incomplete_cin, incomplete_cout, telat = [], [], []

    for index, row in dataAbsensiBulanIni.iterrows():
        if pd.isnull(row['Clock In']):
            incomplete_cin.append(row['Working Date'])
        elif row['LateStart'] <= row['Clock In']:
            telat.append(row['Working Date'])
        if pd.isnull(row['Clock Out']) and row['Working Date'] != currentdate:
            incomplete_cout.append(row['Working Date'])


    message, lupacincout_message = '', ''
    if len(incomplete_cin) == 0 and len(incomplete_cout) == 0 and len(telat) == 0:
        message += 'Selama bulan ini, data absensi anda aman.'
    else:
        if len(telat) > 0:
            message += 'Selama bulan ini, anda pernah telat pada hari-hari berikut:\n'
            for t in range(len(telat)):
                telat[t] = datetranslator(telat[t])
            for t in telat:
                message += t + ',\n'
        message = message[:-2]

        if len(incomplete_cin) > 0:
            for x in range(len(incomplete_cin)):
                incomplete_cin[x] = datetranslator(incomplete_cin[x])
        if len(incomplete_cout) > 0:
            for x in range(len(incomplete_cout)):
                incomplete_cout[x] = datetranslator(incomplete_cout[x])

        lupacincout_message += '\n'
        if len(telat) == 0 and (len(incomplete_cin) > 0 or len(incomplete_cout) > 0):
            lupacincout_message += 'Selama bulan ini, '
        elif len(telat) > 0 and (len(incomplete_cin) > 0 or len(incomplete_cout) > 0):
            lupacincout_message += 'Lalu untuk clock in/clock out, '
        if len(incomplete_cin) > 0:
            lupacincout_message += 'data clock in anda tidak ada untuk: '
            if len(incomplete_cin) > 1:
                lupacincout_message += '\n'
            for x in incomplete_cin:
                lupacincout_message += x + '\n'

        if len(incomplete_cout) > 0:
            if len(incomplete_cin) > 0:
                lupacincout_message += '\nData clock out anda juga ada yang kosong untuk:'
            else:
                lupacincout_message += 'data clock out anda tidak ada untuk: '
            if len(incomplete_cout) > 1:
                lupacincout_message += '\n'
            for x in incomplete_cout:
                lupacincout_message += x + '\n'

    return message + lupacincout_message
