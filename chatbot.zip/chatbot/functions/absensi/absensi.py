from functions.absensi.absensi_functions import *
from functions.getTag.get_tag import getTag

def generateAbsenDataResponse_old(npk, input):
    df = get_cico(npk)
    dfcols = list(df.columns.values)
    print(dfcols)

    similarity, targetcol = getTarget(input, dfcols)
    print(targetcol, similarity, '\n')
    
    response = ''
    if similarity < 0.7:
        response += checkAbsenHariIni(npk) 
        print('Generated response from checkAbsenHariIni:', response)
        # if response != 'Anda belum clock in hari ini. ' and checkAbsenBulanIni(npk) == 'Selama bulan ini, data absensi anda aman.':
        #     response += checkAbsenBulanIni(npk)
        response += checkAbsenBulanIni(npk)
    else:
        for index, row, in df.iterrows():
            response += str(row['Working Date'].date()) + ' - ' + targetcol + ': ' + str(row[targetcol]) + '\n'

    return response

def generateAbsenDataResponse(npk, userinput):
    #get the inner tag for absensi
    mainpath = 'functions/absensi/absensi_model'
    words_jsonpath = f'{mainpath}/words.json'
    classes_jsonpath = f'{mainpath}/classes.json'
    intents_jsonpath = f'{mainpath}/absensi_intents.json'
    model_path = f'{mainpath}/absensimodel.h5'

    tag = getTag(userinput, words_jsonpath, classes_jsonpath, intents_jsonpath, model_path)
    if tag is None:
        return generateDoesntUnderstandResponse()
    else:
        print(f'inner target: {tag}')
    
    
    cicodf = get_cico(npk)
    if 'hari ini' in userinput.lower():
        today = datetime.now().strftime('%Y-%m-%d')
        cicodf = cicodf[cicodf['Working Date'] == today]
    print(cicodf)

    response = ''
    if tag == 'general absensi':
        response = checkAbsenHariIni(npk)
        response += checkAbsenBulanIni(npk)
    elif tag == 'clock in':
        for index, row in cicodf.iterrows():
            if row['Clock In'] is not None:
                response += str(row['Working Date'].date()) + ' - Clock In: ' + str(row['Clock In']) + '\n'
            if response != '' and row['Clock In'] is None:
                response += str(row['Working Date'].date()) + ' - Tidak ada data clock in '
        if response == '':
            response += 'Tidak ada data clock in'
    elif tag == 'clock out':
        for index, row in cicodf.iterrows():
            if row['Clock Out'] is not None:
                response += str(row['Working Date'].date()) + ' - Clock Out: ' + str(row['Clock Out']) + '\n'
            if response != '' and row['Clock Out'] is None:
                response += str(row['Working Date'].date()) + ' - Tidak ada data clock out '
        if response == '':
            response += 'Tidak ada data clock out'
    elif tag == 'telat':
        cicodf = get_cico(npk)
    
    return response