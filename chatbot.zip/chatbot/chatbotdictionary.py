from dependencies import *

#===================================================================================================

#question words
apa = {'apa'} #0
dimana = {'di mana', 'dimana', 'dari mana', 'darimana', 'mana'} #1
siapa = {'siapa'} #2
kapan = {'kapan'} #3
kenapa = {'kenapa'} #4
bagaimana = {'bagaimana', 'gimana'} #5
berapa = {'berapa'} #6
question_words_list = [apa, dimana, siapa, kapan, kenapa, bagaimana, berapa]

ignoresigns = {'.', ',', '!', '?'}

#===================================================================================================

timewords = [
    {'hari ini', 'sekarang', 'today', 'now', 'tadi'},   #today
    {'kemarin', 'yesterday', 'terakhir', 'akhir', 'last', 'kebelakang', 'belakang'},    #past
    {'besok', 'esok', 'tomorrow', 'depan', 'next', 'lagi', 'kedepan'},  #future
    {'minggu', 'week'}, #weekly
    {'bulan', 'month'},  #monthly
    {'tahun', 'year'}   #yearly
]

monthnamelist = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli',
    'Agustus', 'September', 'Oktober', 'November', 'Desember',
    "January", "February", "March", "April", "May", "June", "July", 
    "August", "September", "October", "November", "December"
]






greetings = {'Hi :)', 'Hai', 'Hey there =D',  'Mau ngobrol apa nih'}
yeswords = {'iya', 'ya', 'iye', 'ye', 'yes', 'yep', 'yea', 'yeah',
            'bener', 'benar', 'betul', 'correct', 'right'}
nowords = {'ga', 'gak', 'ngga', 'nggak', 'tidak', 'bukan', 'no', 'nope', 'nah'}
goodbye_words = {'Ok dadah :)', 'OK! See you soon', 'Sampai jumpa lagi', 'Aku duluan ya'}

ignorewords = {'ini', 'itu'}
classifiedwords = {'lahir', 'ultah', 'ulang tahun', 'usia', 'ulangtahun', 'agama'}
rangewords = {'dari', 'sampai', 'sampe'}



usedwords = {'dipakai', 'dipake', 'kepakai', 'kepake', 'terpakai', 'terpake', 'digunakan'}
givenwords = {'dikasih', 'dikasi', 'diberi', 'kasih', 'kasi', 'beri'}


#identity
useridentity = {'saya', 'aku', 'ku', 'gw', 'gua', 'gue'}
botidentity = {'kamu', 'anda', 'lo', 'loe', 'lu'}
targetidentity = {'dia', 'beliau'}
leveljabatan = {'head', 'kepala', 'supervisor', 'spv', 'direktur'}
atasanbawahan = ['atasan', 'bawahan']
identitylist = [useridentity, botidentity, targetidentity]



listingwords = {'saja', 'sajakah', 'list'}
quitchat = {'exit', 'stop', 'quit', 'keluar', 'berhenti', 'udah', 'udahan', 'ud'}
desirewords = {'mau', 'mo', 'ingin', 'want', 'wanna', 'wants'}

locationwords = {'lokasi', 'tempat'}
lastwords = {'terakhir', 'last'}


absenwords = {'absen', 'absensi', 'clockin', 'clock in', 'clockout', 'clock out'}



createwords = {'buat', 'cipta', 'create', 'make'}

#for general questions, no need the where clause for sql query
adm = {'adm', 'astra daihatsu', 'astra daihatsu motor'}

definitions = [['adm', 'PT Astra Daihatsu Motor (ADM) adalah perusahaan otomotif dengan kapasitas produksi terbesar dan memiliki fasilitas Research and Development Center pertama dan terlengkap di Indonesia.']
               , ['terios', 'terios adalah mobil daihatsu paling mewah']
            ]


#================================================= EMPLOYEE =================================================

def getEmployeeQuery():
    employeedataquery = """
    SELECT npk, name, locationNm as location, directorateID, ID_division as ID_divNum, Divisi
    , ID_dept as ID_deptNum, Department, section_id, jabatan_name, level_name, level_idx_no
    , work_date, end_work_date FROM [PM3].[dbo].[viewEmployeeOrganizationAll] a 
    inner join PM3.dbo.location b on a.ID_lokasi = b.ID_lokasi 
    inner join PM3.dbo.sub_golongan c on a.ID_golongan = c.ID_golongan 
    and a.ID_sub = c.ID_sub 
    """
    return employeedataquery

def getEmployeeNamesInMySection(userlevelIDX, levelatasan, id):
    query = f"""
    select Distinct e.name, l.level_name, l.level_idx_no from PM3.dbo.employee e 
    left join PM3.dbo.employee_concurrent ec on e.npk=ec.npk 
    inner join PM3.dbo.levels l on e.ID_level=l.ID_level
    where (l.level_idx_no = {str(levelatasan)}
    or ec.level_idx_no = {str(levelatasan)})
    """
    if levelatasan == 1:
        atasanIDstr = "directorateID"
    elif levelatasan == 2:
        atasanIDstr = "ID_division"
    elif levelatasan >= 3:
        if userlevelIDX > 2:
            atasanIDstr = "ID_dept"
        else:
            atasanIDstr = "ID_division"
    
    query += "and (e." + atasanIDstr + " = " + str(id) + " or ec." + atasanIDstr + " = " + str(id) + " ) "
    query += "and e.resign_dt is null and e.active = 1 order by e.name"

    df = cx.read_sql(conn=sourceconHRIS, query=query)
    # df['level_name'] = df['level_name'].apply(lambda x: x.replace('EC ', '') if 'EC' in x else x)
    return df

def getEmployeeInMySect(userlevelIDX, dirid, divid, deptid):

    df = pd.DataFrame()
    for i in range(1, 8):
        if i == 1:
            tempdf = getEmployeeNamesInMySection(userlevelIDX, i, dirid)
        elif i == 2:
            tempdf = getEmployeeNamesInMySection(userlevelIDX, i, divid)
        else:
            if userlevelIDX == 2:
                tempdf = getEmployeeNamesInMySection(userlevelIDX, i, divid)
            elif userlevelIDX >= 3:
                tempdf = getEmployeeNamesInMySection(userlevelIDX, i, deptid)

        # elif i == 3:
        #   tempdf = getEmployeeNamesInMySection(i, deptid)
        # else:
        #     tempdf = getEmployeeNamesInMySection(i, sectid)
        
        # print('\ntempdf:')
        # print(tempdf)
        df = pd.concat([df, tempdf], ignore_index=True)

    return df.copy()



def getdata_user(npk):
    userdataquery = getEmployeeQuery()
    userdataquery += "where npk = " + str(npk)
    userdata = cx.read_sql(conn=sourceconHRIS, query=userdataquery)
    return userdata

def getdata_Employee():
    employeedataquery = getEmployeeQuery()
    employeedata = cx.read_sql(conn=sourceconHRIS, query=employeedataquery)
    employeedata['name'] = employeedata['name'].apply(lambda x: x.strip())
    employeedata['name'] = employeedata['name'].apply(lambda x: 'ANWAR' if x == 'A N W A R' else x)
    # employeedata['level_name'] = employeedata['level_name'].apply(lambda x: x.replace('EC ', '') if 'EC' in x else x)
    employeedata['level_name'] = employeedata['level_name'].apply(lambda x: 'Division Head' if x == 'Div Head' else x)
    return employeedata

def generateAtasanBawahan(word, userlevelidx, employeedf):
    if word == 'atasan':
        df = employeedf[employeedf['level_idx_no'] < userlevelidx]
    else:
        df = employeedf[employeedf['level_idx_no'] > userlevelidx]
    
    print('\natasan/bawahan:')
    print(df)
    print()

    if df.shape[0] == 0:
        message = 'Anda tidak memiliki ' + word + '\n'
    elif df.shape[0] == 1:
        print('\nWord:', word)
        message = word + ' anda adalah ' + df['name'].values[0] + '\n'
    else:
        message = 'Berikut adalah ' + word + ' anda:\n'
        for index, row, in df.iterrows():
            message += row['level_name'] + ' - ' + row['name'] + '\n'

    return message


#======================================================== TMS =================================================

APR_words = [
    {'approved', 'diterima', 'diapprove', 'diaccept'},
    {'rejected', 'ditolak', 'direject'},
    {'pending', 'on progress'}
]

def getApprover(keyIDList, approvalType):
    approverlist = []
    for key in keyIDList:
        keystr = str(key)
        approverquery = f"""
        select c.name as Approver, a.keyID 
        FROM [PM3].[dbo].[approval_header] a 
        inner join ( 
            select apv_next, approvalID 
            from PM3.dbo.approval_detail a inner join( 
                select min(seq_no) as minSeqNo 
                from PM3.dbo.approval_detail 
                where apv_by is null
            ) b on a.seq_no = b.minSeqNo
        ) b on a.approvalID = b.approvalID 
        inner join PM3.dbo.employee c on b.apv_next = c.npk 
        where a.keyID = {keystr} and apvType = '{approvalType}'
        """
        approver = cx.read_sql(conn=sourceconHRIS, query=approverquery)
        if approver['Approver'].shape[0] != 0:
            approverlist.append(approver['Approver'].values[0])
        else:
            approverlist.append(None)

    return approverlist



#skta
def getdata_skta(npk):
    sktaquery = f'SELECT * FROM [PM3].[dbo].[view_chatbot_skta] where npk = {str(npk)} order by skta_date'
    sktadf = cx.read_sql(conn=sourceconHRIS, query=sktaquery)
    sktadf = sktadf[['skta_date', 'info', 'stats', 'Approver']]

    return sktadf



#cuti
def getdata_cutiquota(npk):
    cutiquotaquery = f"""
    SELECT total as total_cuti_tahunan, remaining as sisa_cuti_tahunan, period_start
    , expired_at, total_long as total_cuti_panjang, remaining_long as sisa_cuti_panjang
    , period_start_long, expired_long FROM [PM3].[dbo].[leave_quota] where npk = {str(npk)}
    """
    return cx.read_sql(conn=sourceconHRIS, query=cutiquotaquery)

def getdata_cutidetails(npk):
    cutiquery = f"select * from view_chatbot_cuti where npk = '{str(npk)}' order by leave_date"
    cutidf = cx.read_sql(conn=sourceconHRIS, query=cutiquery)
    keyidlist = cutidf['leave_id'].values.tolist()

    cutidf['Approver'] = getApprover(keyidlist, 'LEAV') #approval method before 2024

    #approval method after 2024
    for index, row, in cutidf.iterrows():
        if row['Approver'] is None and row['stats'] != 'P':
            if row['apvSPVName'] is not None:
                cutidf.loc[index, 'Approver'] = row['apvSPVName']
            elif row['apvDeptHeadName'] is not None:
                cutidf.loc[index, 'Approver'] = row['apvDeptHeadName']
            elif row['apvAtasanName'] is not None:
                cutidf.loc[index, 'Approver'] = row['apvAtasanName']
    
    return cutidf



#overtime
def get_actualovertime(overtimedf):
    overtime = []
    for index, row, in overtimedf.iterrows():
        hour = int(row['overtime_seconds'] / 3600)
        minute = int((row['overtime_seconds'] - hour * 3600) / 60)

        overtimestr = ''
        if hour > 0:
            overtimestr += str(hour) + ' jam'
        if hour > 0 and minute > 0:
            overtimestr += ' '
        if minute > 0:
            overtimestr += str(minute) + ' menit'
        overtime.append(overtimestr)

    overtimedf['overtime'] = overtime
    keyidlist = overtimedf['overtime_id'].values.tolist()
    overtimedf['Approver'] = getApprover(keyidlist, 'OVER') #approval method before 2024

    #approval method after 2024
    for index, row, in overtimedf.iterrows():
        if row['Approver'] is None and row['stats'] != 'P':
            if row['apvSPVName'] is not None:
                overtimedf.loc[index, 'Approver'] = row['apvSPVName']
            elif row['apvDeptHeadName'] is not None:
                overtimedf.loc[index, 'Approver'] = row['apvDeptHeadName']
            elif row['apvDivHeadName'] is not None:
                overtimedf.loc[index, 'Approver'] = row['apvDivHeadName']
            elif row['apvAtasanName'] is not None:
                overtimedf.loc[index, 'Approver'] = row['apvAtasanName']

    return overtimedf

def getdata_overtime(npk):
    overtimequery = f'select * from view_chatbot_overtime where npk = {str(npk)} order by working_date'
    overtimedf = cx.read_sql(conn=sourceconHRIS, query=overtimequery)
    overtimedf = get_actualovertime(overtimedf)
    overtimedf = overtimedf[['working_date', 'MinClockOut', 'clock_out', 'overtime', 'stats', 'Approver', 'info']]

    return overtimedf



#supem
def getdata_supem(npk):
    supemquery = f'select * FROM [PM3].[dbo].[view_chatbot_supem] where npk = {str(npk)} order by date_start, date_end'
    supemdf = cx.read_sql(conn=sourceconHRIS, query=supemquery)
    keyidlist = supemdf['permission_id'].values.tolist()

    supemdf['Approver'] = getApprover(keyidlist, 'PERM') #approval method before 2024

    #approval method after 2024
    for index, row, in supemdf.iterrows():
        if row['Approver'] is None and row['stats'] != 'P':
            if row['apvSPVName'] is not None:
                supemdf.loc[index, 'Approver'] = row['apvSPVName']
            elif row['apvDeptHeadName'] is not None:
                supemdf.loc[index, 'Approver'] = row['apvDeptHeadName']
            elif row['apvAtasanName'] is not None:
                supemdf.loc[index, 'Approver'] = row['apvAtasanName']

    return supemdf



#ss
def getdata_ss(npk):
    ss_query = f"""
    select concat(year, month) as MonthKey, * from astradaihatsu_wecare.dbo.view_chatbot_ss 
    where npk = '{str(npk)}' order by year, month, ss_title, assessor_level
    """
    ssdf = cx.read_sql(query=ss_query, conn=WeCare_conn)
    return ssdf





#medical plafon
def getquick_medicalplafon(npk):
    medicalplafonquery = f"""
    select limit_medical_plafon, curr_medical_plafon, used_value, startDt, endDt FROM [PM3].[dbo].[emp_plafon] a 
    inner join ( select max(plafonID) as plafonID, npk FROM [PM3].[dbo].[emp_plafon] group by npk ) b on a.npk = b.npk 
    and a.plafonID = b.plafonID where a.npk = {str(npk)}
    """
    medicalplafondata = cx.read_sql(conn=sourceconHRIS, query=medicalplafonquery)

    return medicalplafondata

def getdata_medicalplafon(npk):
    query = f'select * from view_chatbot_medicalplafon where npk = {str(npk)} order by receipt_date'
    medicalplafondetaildf = cx.read_sql(conn=sourceconHRIS, query=query)
    return medicalplafondetaildf

def getdata_kunjunganklinik(npk):
    klinikquery = f"""
    SELECT * FROM [PM3].[dbo].[view_chatbot_klink] where npk = {str(npk)} 
    order by tanggal, jenis_penyakit, nama_obat
    """
    kunjunganklinikdf = cx.read_sql(conn=sourceconHRIS, query=klinikquery)
    return kunjunganklinikdf



medicalplafoninnerwords = [
    {'sisa', 'tinggal', 'sekarang'}, #0 berapa sisanya sekarang
    usedwords, #1 berapa yang kepake
    givenwords, #2 berapa yang dikasih ADM
    {'akhir', 'sampe', 'expiry', 'expired', 'end'} #3 kapan
]



hrislink = "https://adm-hrd.daihatsu.astra.co.id/PM2/Default.aspx"
sktalink = "https://adm-hrd.daihatsu.astra.co.id/PM2/Pages/SKTA/Index.aspx"
supemlink = "https://adm-hrd.daihatsu.astra.co.id/PM2/Pages/SUPEM/Index.aspx"
overtimelink = "https://adm-hrd.daihatsu.astra.co.id/PM2/Pages/SPL/Index.aspx"
cutilink = "https://adm-hrd.daihatsu.astra.co.id/PM2/Pages/CUTI/Index.aspx"
sslink = "https://wecare.daihatsu.astra.co.id/system-suggestion"
mediclink = "https://adm-hrd.daihatsu.astra.co.id/PM2/Pages/ESS/Claim/MedicalClaim.aspx"
availableLinks = ['skta', 'supem', 'overtime', 'cuti', 'ss', 'medicalplafon']



ADMHoliday = {'holiday', 'holidays', 'libur'}
ADMForcedToWork = {'weekend masuk', 'sabtu masuk', 'minggu masuk',
                   'paksa masuk', 'kerja', 'replacement'}
