import pandas as pd

mainpath = "functions/panduan_treasury"
excelpath = f"{mainpath}/LIST PERTANYAAN FIX.xlsx"
sop_excel_path = f"{mainpath}/SOP files/panduan_SOP.xlsx"

def get_all_data():
    excelfile = pd.ExcelFile(excelpath)
    sheetname_list = excelfile.sheet_names

    maindf = pd.DataFrame()
    for sheetname in sheetname_list:
        df = pd.read_excel(excelpath, sheetname)
        maindf = pd.concat([maindf, df], ignore_index=True)
    
    
    maindf['Category'] = maindf['Category'].apply(lambda x: x.strip())

    return maindf

maindf = get_all_data()