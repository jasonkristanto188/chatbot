#using flask_restful
from flask import Flask, jsonify, request
from flask_restful import Resource, Api
from flask_cors import CORS
from bs4 import BeautifulSoup

from chatbotwecare import chatbotrun

# creating the flask app
app = Flask(__name__)

# creating an API object
api = Api(app)
CORS(app)



class chatBot(Resource):
    def get(self):
        user_input = request.args.get('question')
        npk = request.args.get('npk')
        soup = BeautifulSoup(user_input, 'html.parser') #clean any HTML scripts
        user_input = soup.get_text()
        answer, seeMore = chatbotrun(user_input=user_input, NPK=npk)
        return jsonify({'message': str(answer)})
    def post(self):
        #json is the data that we want to send to WeCare server
        #the json data contains question and npk values
        #store these values into variables
        data = request.get_json() 
        user_input = str(data.get('question')) 
        npk = str(data.get('npk')) 
        soup = BeautifulSoup(user_input, 'html.parser') #clean any HTML scripts
        user_input = soup.get_text()
        answer, seeMore = chatbotrun(user_input=user_input, NPK=npk)
        
        return jsonify({'message': str(answer), 'see_more': seeMore})



# adding the defined resources along with their corresponding urls
# api.add_resource(chatBot, '/input')
api.add_resource(chatBot, '/chatbot-api/chatbot')

# driver function
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=7000, debug=True) #skrng harus 80 atau 443

