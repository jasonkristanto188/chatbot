from chatbotfunctions import *

#===================================================================================================

def chatbotrun(user_input, NPK):
    npk = NPK
    userinput = user_input.lower()
    userinput = userinput.lower().strip()
    start_chainlist(npk)
    chainlist = get_chainlist(npk)  #this is already in type list!
    os.system('cls') if   os.name == 'nt' else os.system('clear')
    print('chainlist:', chainlist)

    #get the tag. getTag function is in chatbotfunctions.py
    from functions.getTag import get_tag

    words_jsonpath = 'model/words.json'
    classes_jsonpath = 'model/classes.json'
    intents_jsonpath = 'model/intents.json'
    model_path = 'model/chatbotmodel.h5'

    tag = get_tag.getTag(userinput, words_jsonpath, classes_jsonpath, intents_jsonpath, model_path)

    if get_chainlist_length(npk) > 1:
        tag = 'panduan treasury'

    if tag == 'yeswords':
        if getPrevTag() is not None:
            tag = getPrevTag()
            update_continueChat(True)
        else:
            response = generateDoesntUnderstandResponse()

    if tag == 'nowords':
        if getPrevTag() is not None:
            if getPrevTag() == 'employee_data':
                tag = getPrevTag()
            else:
                response = "Ok deh. Ada lagi yang bisa saya bantu?"
        else:
            response = generateDoesntUnderstandResponse()

    if tag == 'greetings':
        response = greetings.pop()
        greetings.add(response)
    elif tag == 'dean':
        response = generateDeanResponse(userinput)
    elif tag == 'user_data_full':
        response = generateUserDataResponse(npk, tag, userinput)
    elif tag == 'user_data':
        response = generateUserDataResponse(npk, tag, userinput)
    elif tag == 'absensi':
        from functions.absensi import absensi
        response = absensi.generateAbsenDataResponse(npk, userinput)
    elif tag == 'employee_data':
        response = generateEmployeeDataResponse(npk, userinput)
    elif tag == 'cuti':
        response, seeMore = generateCutiDataResponse(npk, userinput)
    elif tag == 'skta':
        response, seeMore = generateSKTADataResponse(npk, userinput)
    elif tag == 'supem':
        response, seeMore = generateSupemDataResponse(npk, userinput)
    elif tag == 'overtime':
        response, seeMore = generateOvertimeDataResponse(npk, userinput)
    elif tag == 'system_suggestion':
        response, seeMore = generateSSDataResponse(npk, userinput)
    elif tag == 'medicalplafon':
        response, seeMore = generateMedicalPlafonResponse(npk, userinput)
    elif tag == 'jadwal':
        response = generateCalendarResponse(npk, userinput)
    elif tag == 'buat_claims':
        response = generateLinks(userinput)
    elif tag == 'baca_berita':
        response = getADMNews()
    elif tag == 'PO_status':
        from functions.prpoia_purchases import prpoia
        response = prpoia.generatePOstatusResponse(userinput)
    elif tag == 'IA-PR-PO':
        from functions.prpoia_purchases import prpoia
        response = prpoia.generateIAPRPOresponse(userinput)
    elif tag == 'materialGA':
        from functions.prpoia_purchases import material_purchases
        response = material_purchases.generateGAMaterialResponse(userinput)
    elif tag == 'avg_harga_material':
        from functions.prpoia_purchases import material_purchases
        response = material_purchases.avgHargamaterial(userinput)
    elif tag == 'division_purchases':
        from functions.prpoia_purchases import material_purchases
        response = material_purchases.generateDivPurchaseResponse(userinput)
    elif tag == 'self_purchases':
        from functions.prpoia_purchases import material_purchases
        response = material_purchases.generateSelfPurchaseResponse(userinput, npk)
    elif tag == 'booking ruangan':
        from functions.booking_ruangan import booking_ruangan
        response = booking_ruangan.generateBookingRuanganResponse(userinput)
    elif tag == 'panduan treasury' or (tag is None and chainlist[0] == 'panduan treasury'):
        tag = 'panduan treasury'
        from functions.panduan_treasury import panduan_treasury
        response = panduan_treasury.generate_panduan_treasury_response(npk, userinput, chainlist)
    else:
        if npk == '74667':
            response = search_employee(userinput)
            if response is None:
                response = generateDoesntUnderstandResponse()
        else:
            response = generateDoesntUnderstandResponse()

    response = str(response).strip()

    from functions.general_functions import chatbot_logs
    chatbot_logs.generatePythonLog(npk, tag, userinput, response)
    # collectData(npk, tag, userinput, response)

    response = response.replace('\n', '<br>')   #this is for WeCare only
    
    if tag not in ['cuti', 'skta', 'supem', 'overtime', 'system_suggestion', 'medicalplafon', 'panduan_treasury']:
        seeMore = False

    if tag not in ['panduan treasury']:
        clear_chainlist(npk)

    if seeMore is False and tag != 'employee_data':
        resetChat()

    return response, seeMore
