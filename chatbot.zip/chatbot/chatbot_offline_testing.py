from chatbotwecare import *
import os

npk = '74667'
quit = False

while not quit:
    userinput = input("Press 'q' to quit\nEnter prompt: ").strip()

    if userinput.lower() == 'q':
        os.system('cls') if os.name == 'nt' else os.system('clear')
        quit = True
    else:
        response, seeMore = chatbotrun(userinput, npk)
        # os.system('cls') if   os.name == 'nt' else os.system('clear')
        response = response.replace('<br>', '\n')
        print(response)
        del response, seeMore