from keras.models import load_model

#===================================================================================================

from sqlalchemy import create_engine
import connectorx as cx
import pandas as pd
import urllib
import pyodbc

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()    #used in clean_up_sentence function

import os
import shutil
import re
import json
import spacy
import numpy as np
import itertools
import textdistance
from collections import Counter
from deep_translator import GoogleTranslator
from thefuzz import fuzz
import difflib

import datetime as dt
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

#===================================================================================================

with open('credentials.json', 'r') as f:
    cred = json.load(f)

OneSystem_cred = cred['OneSystem']
sourceconOneSys = f"mssql://{OneSystem_cred['username']}:{urllib.parse.quote_plus(OneSystem_cred['password'])}@{OneSystem_cred['server']}/{OneSystem_cred['database']}"

WeCare_cred = cred['WeCare']
WeCare_conn = f"mssql://{WeCare_cred['username']}:{urllib.parse.quote_plus(WeCare_cred['password'])}@{WeCare_cred['server']}/{WeCare_cred['database']}"
WeCare_conn_forInsert = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={WeCare_cred['server']};DATABASE={WeCare_cred['database']};UID={WeCare_cred['username']};PWD={WeCare_cred['password']}"

HRIS_cred = cred['HRIS']
sourceconHRIS = f"mssql://{HRIS_cred['username']}:{urllib.parse.quote_plus(HRIS_cred['password'])}@{HRIS_cred['server']}/{HRIS_cred['database']}"
HRIS_conn_forInsert = f"Driver={{ODBC Driver 17 for SQL Server}};SERVER={HRIS_cred['server']};DATABASE={HRIS_cred['database']};UID={HRIS_cred['username']};PWD={HRIS_cred['password']}"
