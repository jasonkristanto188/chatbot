from chatbotdictionary import *
from functions.general_functions.dean_auto_responses import *

#===================================================================================================

def collectData(npk, tag, userinput, response):
    print('\ncollecting data....\n')
    df = getdata_user(npk)

    templist = []
    templist.append(df['ID_divNum'].values.tolist()[0])
    templist.append(df['Divisi'].values.tolist()[0])
    templist.append(tag)
    templist.append(userinput)
    templist.append(response)
    
    newdf = pd.DataFrame([templist], columns = ['ID_division', 'Division', 'Tag', 'Userinput', 'Response'])

    if newdf.shape[0] > 0:
        conn = pyodbc.connect(WeCare_conn_forInsert)
        cursor = conn.cursor()

        for index, row in newdf.iterrows():
            cursor.execute("""
                INSERT INTO [astradaihatsu_wecare].[dbo].[LogChatbot] 
                ([ID_division], [Division], [Tag], [Userinput], [Response], [InsertedDate])
                values (?,?,?,?,?,?)
            """, row['ID_division'], row['Division'], row['Tag']
            , row['Userinput'], row['Response'], datetime.datetime.now()
            )
        
        conn.commit()
        print('\nData SUCCESSFULLY inserted to db!\n')

#===================================================================================================

# Dictionary to store chainlists for each user
user_chainlists = {}

def start_chainlist(npk):
    global user_chainlists

    # Initialize an empty chainlist for the user if not already present
    if npk not in user_chainlists:
        user_chainlists[npk] = []

def get_chainlist_length(npk):
    # Retrieve the user's chainlist and return its length
    global user_chainlists
    return len(user_chainlists.get(npk, []))

def get_chainlist(npk):
    global user_chainlists

    # Retrieve the user's chainlist in type list, not dict!
    return user_chainlists.get(npk, [])

def append_to_chainlist(npk, message):
    global user_chainlists

    # Add a message to the user's chainlist
    if npk in user_chainlists:
        user_chainlists[npk].append(message)

def pop_from_chainlist(npk):
    global user_chainlists

    # Delete the latest message from the user's chainlist
    if npk in user_chainlists:
        user_chainlists[npk].pop()

def clear_chainlist(npk):
    global user_chainlists

    # Clears every data from that user's chainlist
    if npk in user_chainlists:
        user_chainlists[npk].clear()


# chainlist = []

# def get_chainlist_old():
#     global chainlist
#     return chainlist

# def append_to_chainlist_old(value):
#     global chainlist
#     chainlist.append(value)

# def pop_from_chainlist_old():
#     global chainlist
#     chainlist.pop()

# def clear_chainlist_old():
#     global chainlist
#     chainlist.clear()
    
prevTag = None
def getPrevTag():
    global prevTag
    return prevTag

def update_PrevTag(value):
    global prevTag
    prevTag = value

continueChat = False
def getContinueChat():
    global continueChat
    return continueChat

def update_continueChat(booleanValue):
    global continueChat
    continueChat = booleanValue

tempEmployeeNamesList = None
def get_tempEmployeeNames():
    global tempEmployeeNamesList
    return tempEmployeeNamesList

def update_tempEmployeeNames(list):
    global tempEmployeeNamesList
    tempEmployeeNamesList = list

targetPerson = None
def getTargetPerson():
    global targetPerson
    return targetPerson

def update_TargetPerson(person):
    global targetPerson
    targetPerson = person

def resetChat():
    update_PrevTag(None)
    update_continueChat(False)
    update_tempEmployeeNames(None)
    update_TargetPerson(None)

#===================================================================================================

def getQuestionType(userinput):
    breakinput = userinput.split()
    questiontype = None
    questionword = ''
    for word in breakinput:
        for index, question_words in enumerate(question_words_list):
            if word in question_words:
                return index, str(word)

    return questiontype, questionword

def removeQuestionWords(user_input):
    breakinput = user_input.split()

    temp = [word for word in breakinput if any(word in question_words for question_words in question_words_list)]
    return ' '.join([word for word in breakinput if word not in temp])

def filterwords(userinput):
    usefulinput = re.sub(r'[^\w\s]', '', userinput)
    words = word_tokenize(usefulinput)
    stop_words = set(stopwords.words('indonesian'))
    filtered_words = [word for word in words if word.casefold() not in stop_words]
    filtered_string = ' '.join(filtered_words)
    return filtered_string

#text similarity
def getTarget(filtered_string, data):
    filtered_string = filtered_string.lower()

    maxsimilarity = 0
    accuratetarget = ''
    for target in data:
        # print('Target:', target)
        if filtered_string.lower() == str(target).lower(): #if exact match found
            return 1, target

        jarowrinkler_similarity = textdistance.jaro_winkler.normalized_similarity(filtered_string.lower(), target.lower())
        # cosine_similarity = textdistance.cosine.normalized_similarity(filtered_string.lower(), target.lower())

        similarity_method = jarowrinkler_similarity
        # similarity_method = cosine_similarity

        if maxsimilarity < similarity_method:
            maxsimilarity = similarity_method
            accuratetarget = target

    return maxsimilarity, accuratetarget

#===================================================================================================

# understanding human speech

def googleTranslate(input, sourcelangid, targetlangid):
    return GoogleTranslator(source=sourcelangid, target=targetlangid).translate(input)

def partOfSpeechTagging(userinput, taglist):
    # source: https://www.geeksforgeeks.org/part-speech-tagging-stop-words-using-nltk-python/
    
    tokenized = sent_tokenize(userinput)

    tagged = None
    for i in tokenized:
        
        # Word tokenizers is used to find the words and punctuation in a string
        wordsList = nltk.word_tokenize(i)
    
        # removing stop words from wordList
        # wordsList = [w for w in wordsList if not w in stop_words]
    
        # Using a Tagger. Which is part-of-speech
        # tagger or POS-tagger.
        tagged = nltk.pos_tag(wordsList)
        print(tagged)
    
    templist = []
    for tag in taglist:
        for x in tagged:
            if x[1] == tag:
                templist.append(x[0])
    
    concatenated_string = " ".join(templist)
    
    return concatenated_string

def spacy_Tag(userinput, taglist):

    # Load the spaCy model
    # python -m spacy download en_core_web_sm

    nlp = spacy.load('en_core_web_sm')

    # Process the text
    doc = nlp(userinput)

    # Extract the POS tag for each token in the text
    tagged_text = [(token.text, token.pos_) for token in doc]
    print(tagged_text)
    print()

    # Convert the list of tuples into a string
    if len(taglist) > 0:
        tagged_text_str = ' '.join([f"{word}" for word, tag in tagged_text if tag in taglist])
    else:
        tagged_text_str = ' '.join([f"{word}" for word, tag in tagged_text])

    return tagged_text_str

#===================================================================================================

# Data Employee

def generateDeanResponse(userinput):
    response = 'Aku Dean, Daihatsu Employee Assistant. Apakah ada yang bisa saya bantu?'

    questiontype, _ = getQuestionType(userinput)
    if questiontype == 0 or 'help' in userinput:   #apa
        response = "Sebagai Daihatsu Employee Assistant, saya bisa menampilkan data-data anda terkait " + \
        "absen, skta, atasan/bawahan, medical plafon, dll.\n\n" + \
        "Beberapa contoh yang bisa anda coba:\n" + \
        '"cuti saya", "cek supem", "buat ss", "dept head saya siapa", "berita adm"'
        
    elif questiontype == 2:   #siapa
        if any(createword in userinput for createword in createwords):
            response = 'Aku dibuat oleh Jason Kristanto'
    elif questiontype == 3: #kapan
        response = 'Aku diciptakan pada tanggal 27 Juni, 2023'

    return response

def search_employee(userinput):
    employeedf = getdata_Employee()
    print(employeedf.info())
    indonesian_names = employeedf['name'].values.tolist()

    words_detected = set()
    nameset = set()
    for fullname in indonesian_names:
        for name in fullname.split():
            if name.lower() in userinput.lower().split():
                words_detected.add(name.lower())
                nameset.add(fullname)
    
    namelist = []
    while len(nameset) > 0:
        name = nameset.pop()
        namelist.append(name)

    words = ' '.join(words_detected)

    if len(namelist) == 1:
        targetname = namelist[0]
        del namelist
        
        jabatan = employeedf['jabatan_name'][employeedf['name'] == targetname].values[0] 
        division = employeedf['Divisi'][employeedf['name'] == targetname].values[0]
        department = employeedf['Department'][employeedf['name'] == targetname].values[0]
        return f'{targetname} adalah {jabatan} di {division}, {department}'
    elif len(namelist) >= 1:
        targetname = None
        for name in namelist:
            count = 0
            for word in words_detected:
                if word.lower() in name.lower():
                    count += 1
                if count == len(words_detected):
                    targetname = name
                    break
            
            if targetname is not None:
                break
        
        if targetname is None:
            max_similarity_score = 0
            for name in namelist:
                jarowrinkler_similarity = textdistance.jaro_winkler.normalized_similarity(name.lower(), words.lower())
                if jarowrinkler_similarity > max_similarity_score:
                    max_similarity_score = jarowrinkler_similarity
                    targetname = name
        
        del namelist
        jabatan = employeedf['jabatan_name'][employeedf['name'] == targetname].values[0] 
        division = employeedf['Divisi'][employeedf['name'] == targetname].values[0]
        department = employeedf['Department'][employeedf['name'] == targetname].values[0]
        return f'{targetname} adalah {jabatan} di {division}, {department}'
    else:
        return None

def generateUserDataResponse(npk, tag, userinput):
    userdata = getdata_user(npk)

    name = userdata['name'].values[0]
    level = userdata['level_name'].values[0]
    dept = userdata['Department'].values[0]
    division = userdata['Divisi'].values[0]
    location = userdata['location'].values[0]
    gabungadm = userdata['work_date'].values[0]
    tanggalgabungadm, waktugabungadm = numpydatetime64_to_datetime(gabungadm)

    if tag == 'user_data_full':
        return 'Anda ' + name + ', ' + level + ' di divisi ' + division + ', department ' + dept + ', '\
                    + location + '.\nAnda bergabung dengan ADM pada hari ' + str(tanggalgabungadm) + '.\n'
    elif tag == 'user_data':
        selfIdentityMessage = ''
        questiontype, questionword = getQuestionType(userinput)
        print(questiontype, questionword)

        filtered_string = filterwords(userinput)
        if filtered_string == '':
            return generateDoesntUnderstandResponse()

        if questiontype is None:
            similarity, target = getTarget(filtered_string, userdata.columns.values.tolist())
            selfIdentityMessage += target + ' anda adalah ' + str(userdata[target].values[0]) + '\n'
        elif questiontype == 0:
            userdata = userdata[['name', 'level_name', 'Department', 'Divisi']]
            similarity, target = getTarget(filtered_string, userdata.columns.values.tolist())
            selfIdentityMessage += target + ' anda adalah ' + userdata[target].values[0] + '\n'
        elif questiontype == 1:
            selfIdentityMessage += 'Anda di ' + location + '\n'
        elif questiontype == 3:
            selfIdentityMessage += 'Anda bergabung dengan ADM pada tanggal ' + tanggalgabungadm + '\n'
        
        return selfIdentityMessage

def generateEmployeeDataResponse(npk, userinput):
    breakinput = userinput.split()

    #replace div, dept, spv with division, department, supervisor respectively
    for word in breakinput:
        if word == 'div':
            userinput = userinput.replace('div', 'division')
        if word == 'dept':
            userinput = userinput.replace('dept', 'department')
        if word == 'spv':
            userinput = userinput.replace('spv', 'supervisor')

    translated = googleTranslate(userinput, 'id', 'en')
    
    taglist = ['NOUN', 'PROPN', 'NUM']
    spok = spacy_Tag(translated, taglist)



    employeedf = getdata_Employee()
    employeedf = employeedf.sort_values(by='level_idx_no')

    userdata = getdata_user(npk)
    userlevel = userdata['level_name'].values[0]
    userlevelIDX = userdata['level_idx_no'].values[0]
    dirid = userdata['directorateID'].values[0]
    divid = userdata['ID_divNum'].values[0]
    deptid = userdata['ID_deptNum'].values[0]
    # sectid = userdata['section_id'].values[0]

    print(userdata[['level_name', 'level_idx_no', 'ID_divNum', 'ID_deptNum', 'section_id']])

    employeeInMyDept = getEmployeeInMySect(userlevelIDX, dirid, divid, deptid)
    print(employeeInMyDept)
    
    questiontype, questionword = getQuestionType(userinput)
    userinput = userinput.replace(questionword, '')
    breakinput = userinput.split()

    message = ''
    for word in breakinput:
        if word == 'atasan' or word == 'bawahan':
            print('\ngetting atasan or bawahan...\n')
            return generateAtasanBawahan(word, userlevelIDX, employeeInMyDept)



    if getTargetPerson() is not None:
        colName = 'name'
    else:
        colName = None

        for word in breakinput:
            if word == 'head' or word == 'spv':
                colName = 'level_name'
                break

        if colName == None:
            tempdf = employeedf[['name', 'location', 'Divisi', 'Department', 'level_name']]
            employeeDataColumns = tempdf.columns.values.tolist()

            maxsimilarity = 0
            colName = None
            for col in employeeDataColumns:
                similarity, target = getTarget(userinput, employeedf[col])
                if maxsimilarity < similarity:
                    maxsimilarity = similarity
                    colName = col

            similarity, target = getTarget(userinput, employeeDataColumns)
            if maxsimilarity < similarity:
                colName = target



    if colName == 'level_name':
        similarity, levelname = getTarget(userinput, employeeInMyDept['level_name'])
        levelidx = employeeInMyDept.loc[employeeInMyDept['level_name'] == levelname, 'level_idx_no'].iloc[0]
        
        message = ''
        if levelidx >= userlevelIDX:
            message += 'Anda tidak memiliki ' + levelname + ' karena anda adalah seorang ' + userlevel
            if levelidx > userlevelIDX:
                message += '. Namun anda bisa coba "siapa bawahan saya" '
        else:
            useddf = employeeInMyDept[employeeInMyDept['level_idx_no'] == levelidx]

            if useddf.shape[0] == 1:
                message += useddf['level_name'].values[0] + ' anda adalah '
            elif useddf.shape[0] > 1:
                message += 'Berikut adalah ' + useddf['level_name'].values[0] + ' anda:\n'
            for index, row, in useddf.iterrows():
                message += row['name'] + '\n'

    elif colName == 'name':
        namemaybe = filterwords(userinput) if len(userinput.split()) > 1 else userinput
        print('Name detected from user input:', namemaybe)

        if get_tempEmployeeNames() is None:
            if namemaybe == '':
                return generateDataNotFoundResponse()
            else:
                temp = [name for name in employeedf['name'] if
                        any(breakname.lower() in name.lower() for breakname in namemaybe.split()) and name != '']
                update_tempEmployeeNames(temp)

        nametemp = get_tempEmployeeNames()
        if len(nametemp) == 0:
            message = generateDataNotFoundResponse()
        else:
            similarity, target = getTarget(namemaybe, nametemp)
            person = ''

            if similarity >= 1:
                person = target
            else: #similarity < 1
                if getTargetPerson() is None:
                    update_TargetPerson(target)
                    update_PrevTag('employee_data')
                    update_continueChat(True)
                    return "Maksud anda " + getTargetPerson() + "?"
                else:
                    fullbreak = False

                    for word in userinput.split():
                        if fullbreak:
                            break
                        for yes in yeswords:
                            if yes == word or similarity == 1:
                                person = getTargetPerson()
                                fullbreak = True
                                break
                        if not fullbreak:
                            nametemp.remove(getTargetPerson())
                            update_tempEmployeeNames(nametemp)

                            if len(nametemp) > 0:
                                if namemaybe != '':
                                    similarity, target = getTarget(namemaybe, nametemp)
                                else:
                                    target = nametemp[0]
                                update_TargetPerson(target)
                                return "Maksud anda " + target + "?"
                            else:
                                return generateDataNotFoundResponse()

            resetChat()

            result = employeedf.loc[employeedf['name'] == person]
            message = result['name'].values[0] + ' adalah ' + result['level_name'].values[0] + ' di ' + \
                     result['Divisi'].values[0] + ', ' + result['Department'].values[0] + ', ' \
                      + result['location'].values[0]

    return message



#===================================================================================================

def getCalendarData(npk):
    currentyear = getCurrentYear()
    holidayquery = f"""
    SELECT cast(calendar_date as date) as calendar_date, DWS_Type FROM [PM3].[dbo].[emp_work_schdl] 
    where year(calendar_date) = {str(currentyear)} and npk = '{str(npk)}' order by calendar_date
    """
    holidaydates = cx.read_sql(conn=sourceconHRIS, query=holidayquery)
    return holidaydates

def datetranslator(date):
    datedayname = date.strftime("%A")
    switcher = {
        'monday': 'Senin',
        'tuesday': 'Selasa',
        'wednesday': 'Rabu',
        'thursday': 'Kamis',
        'friday': 'Jumat',
        'saturday': 'Sabtu',
        'sunday': 'Minggu'
    }
    datedayname = switcher.get(datedayname.lower(), datedayname)

    datemonthname = monthnamelist[date.month - 1]

    dateday = date.day
    dateyear = date.year

    timestring = datedayname + ', ' + str(dateday) + ' ' + datemonthname + ' ' + str(dateyear)
    return timestring

def numpydatetime64_to_datetime(datetimedata):
    print('\ndatetimedata:', datetimedata, '\n')
    newdt = dt.datetime.utcfromtimestamp(datetimedata.tolist() / 1e9)
    datestr = datetranslator(newdt)
    timestr = newdt.strftime('%H:%M:%S')
    return datestr, timestr

def generateCalendarResponse(npk, userinput):
    holidayDates = getHoliday(npk)
    forcedWorkDates = getWeekendWork(npk)

    #check if user wants to display all calendar, or holiday/forced to work only
    holidayCheck = None
    for holidayWord in ADMHoliday:
        if holidayCheck:
            break
        if holidayWord in userinput:
            holidayCheck = all(noword not in userinput for noword in nowords)

    for forcedWork in ADMForcedToWork:
        if forcedWork in userinput:
            holidayCheck = False
            break

    print('\nHoliday check:', holidayCheck)

    timetarget = next((i for i, words in enumerate(timewords) if any(word in userinput for word in words)), None)

    currentyear = datetime.datetime.now().year
    holidayResponse = f'Berikut adalah tanggal-tanggal libur anda di tahun {currentyear}:\n'
    notHolidayReponse = f'Berikut adalah tanggal-tanggal replacement day anda di tahun {currentyear}:\n'

    currentdate = datetime.now().strftime('%Y-%m-%d')
    current_timestamp = pd.Timestamp(currentdate)
    for date in holidayDates:
        if timetarget is None or \
                (timetarget == 0 and current_timestamp == date) or \
                (timetarget == 1 and current_timestamp > date) or \
                (timetarget == 2 and current_timestamp < date):
            holidayResponse += str(datetranslator(date)) + '\n'
            if (timetarget == 1 and 'terakhir' in userinput) or \
                    (timetarget == 2 and 'lagi' in userinput):
                break

    if holidayCheck is True:
        return holidayResponse

    current_timestamp = pd.Timestamp(currentdate)
    for date in forcedWorkDates:
        if timetarget is None or \
                (timetarget == 0 and current_timestamp == date) or \
                (timetarget == 1 and current_timestamp > date) or \
                (timetarget == 2 and current_timestamp < date):
            notHolidayReponse += str(datetranslator(date)) + '\n'
            if (timetarget == 1 and 'terakhir' in userinput) or \
                    (timetarget == 2 and 'lagi' in userinput):
                break

    if holidayCheck is False:
        return notHolidayReponse

    if holidayCheck is None:
        return holidayResponse + '\n' + notHolidayReponse

def getHoliday(npk):
    holidaydates = getCalendarData(npk)
    holidayDates = []

    for index, row in holidaydates.iterrows():
        if row['DWS_Type'] == 'Free':
            datestring = datetranslator(row['calendar_date'])
            if 'Sabtu' not in datestring and 'Minggu' not in datestring:
                holidayDates.append(row['calendar_date'])
    return holidayDates

def getWeekendWork(npk):
    holidaydates = getCalendarData(npk)
    forcedWorkDates = []
    for index, row in holidaydates.iterrows():
        if row['DWS_Type'] == 'Work day':
            datestring = datetranslator(row['calendar_date'])
            if 'Sabtu' in datestring or 'Minggu' in datestring:
                forcedWorkDates.append(row['calendar_date'])

    return forcedWorkDates

#===================================================================================================

# TMS

def generateClaimsCount(df, type, questiontype):
    message = ''
    buatclaim = ''
    
    if type.lower() == 'skta' or type.lower() == 'supem':
        buatclaim += 'buat'
    else:
        buatclaim += 'claim'



    dflen = df.shape[0]
    if dflen == 0:
        message += 'Anda tidak pernah ' + buatclaim + ' ' + type
    else:
        message += 'Anda sudah ' + buatclaim + ' ' + type + ' sebanyak ' + str(dflen) + ' kali\n'

    if questiontype == 6:
        return message



    approveddf = df[df['stats'] == 'A']
    rejecteddf = df[df['stats'] == 'R']
    pendingdf = df[df['stats'] == 'P']

    len_approved = approveddf.shape[0]
    len_rejected = rejecteddf.shape[0]
    len_pending = pendingdf.shape[0]



    if len_approved > 0:
        if len_approved == dflen:
            message += 'Semua ' + type + ' anda sudah diapprove.'
        else:
            message += str(len_approved) + ' sudah diapprove'
    if (len_approved > 0 and len_rejected > 0) or (len_approved > 0 and len_pending > 0):
        message += ', '
    if len_rejected > 0:
        if len_rejected == dflen:
            message += 'Semua ' + type + ' anda ditolak.'
        else:
            message += str(len_rejected) + ' ditolak'
    if len_rejected > 0 and len_pending > 0:
        message += ', '
    if len_pending > 0:
        if len_pending == dflen:
            message += 'Semua ' + type + ' anda masih on progress.'
        else:
            message += str(len_pending) + ' on progress.'

    return message + '\n'

def temp(type, approvalType, df, datecol):
    info = 'reason' if type == 'cuti panjang' or type == 'cuti tahunan' else 'info'
    message = ''

    for index, row, in df.iterrows():
        message += str(row[datecol].date()) + approvalType + str(row['Approver'])
        if type == 'cuti tahunan':
            message += '\nCuti tahunan yang dipakai: ' + str(row['days_leave']) + ' hari'
        elif type == 'cuti panjang':
            message += '\nCuti panjang yang dipakai: ' + str(row['days_long_leave']) + ' hari'
        message += '\nAlasan ' + type + ': ' + str(row[info]) + '\n\n'
    message += '\n'

    return message

def generateAPRmessage(df, type, datecol):
    print(df)

    approveddf = df[df['stats'] == 'A']
    rejecteddf = df[df['stats'] == 'R']
    pendingdf = df[df['stats'] == 'P']

    len_approved = approveddf.shape[0]
    len_rejected = rejecteddf.shape[0]
    len_pending = pendingdf.shape[0]

    message = ''

    if len_pending > 0:
        print('\nGenerating pending message....')
        approvalType = '\nPending at: '
        message += 'On progress:\n' + temp(type, approvalType, pendingdf, datecol)

    if len_approved > 0:
        print('\nGenerating approval message....')
        approvalType = '\nApproved by: '
        message += 'Approved:\n' + temp(type, approvalType, approveddf, datecol)

    if len_rejected > 0:
        print('\nGenerating rejection message....')
        approvalType = '\nRejected by: '
        message += 'Rejected:\n' + temp(type, approvalType, rejecteddf, datecol)

    

    return message + '\n'

def getAPRstats(message):
    maxsimilarity = 0
    itarget = 0

    breakinput = message.split()
    for i in range(len(APR_words)):
        for word in breakinput:
            for questionword in APR_words[i]:
                if word == questionword:
                    if i == 0:
                        return 'A'
                    elif i == 1:
                        return 'R'
                    elif i == 2:
                        return 'P'

        similarity, target = getTarget(message, APR_words[i])
        if maxsimilarity < similarity:
            maxsimilarity = similarity
            itarget = i

    if itarget == 0:
        return 'A'
    elif itarget == 1:
        return 'R'
    else:
        return 'P'

def generateSKTADataResponse(npk, userinput):
    sktadf = getdata_skta(npk)

    if sktadf.shape[0] == 0:
        return 'Anda tidak pernah buat SKTA', False

    if getContinueChat() is False:
        questiontype, questionword = getQuestionType(userinput)
        update_PrevTag('skta')
        return generateClaimsCount(sktadf, 'SKTA', questiontype), True
    elif getContinueChat() is True and getPrevTag() == 'skta':
        return generateAPRmessage(sktadf, 'SKTA', 'skta_date'), False

def generateSupemDataResponse(npk, userinput):
    supemdf = getdata_supem(npk)
    supemdf = supemdf[['permission_date', 'date_start', 'date_end', 'permit_name'
        , 'info', 'stats', 'reason', 'Approver']]

    if supemdf.shape[0] == 0:
        return 'Anda tidak pernah buat supem', False

    if getContinueChat() is False:
        questiontype, questionword = getQuestionType(userinput)
        update_PrevTag('supem')
        return generateClaimsCount(supemdf, 'supem', questiontype), True
    elif getContinueChat() is True and getPrevTag() == 'supem':
        return generateAPRmessage(supemdf, 'supem', 'permission_date'), False

def generateOvertimeDataResponse(npk, userinput):
    overtimedf = getdata_overtime(npk)
    print('overtime df length:', overtimedf.shape[0])
    #column names: working_date, MinClockOut, clock_out, overtime, stats, Approver, info

    if overtimedf.shape[0] == 0:
        return 'Anda tidak pernah claim overtime', False

    if getContinueChat() is False:
        questiontype, questionword = getQuestionType(userinput)
        update_PrevTag('overtime')
        return generateClaimsCount(overtimedf, 'overtime', questiontype), True
    elif getContinueChat() is True and getPrevTag() == 'overtime':
        return generateAPRmessage(overtimedf, 'overtime', 'working_date'), False

def generateCutiDataResponse(npk, user_input):
    cutiquota = getdata_cutiquota(npk)
    if cutiquota.shape[0] == 0:
        return 'Anda tidak memiliki jatah cuti', False

    total_cuti_tahunan = cutiquota['total_cuti_tahunan'].values[-1]
    sisa_cuti_tahunan = cutiquota['sisa_cuti_tahunan'].values[-1]

    total_cuti_panjang = cutiquota['total_cuti_panjang'].values[-1]
    sisa_cuti_panjang = cutiquota['sisa_cuti_panjang'].values[-1]
    startDate_cuti_panjang = cutiquota['period_start_long'].values[-1]
    expiredDate_cuti_panjang = cutiquota['expired_long'].values[-1]



    cutidf = getdata_cutidetails(npk)

    cutitahunan = cutidf[cutidf['leaveType'] == 'Cuti Tahunan']
    cutipanjang = cutidf[cutidf['leaveType'] == 'Cuti Panjang']



    if getContinueChat() is False:
        cutimessage = ''

        questiontype, questionword = getQuestionType(user_input)

        if questiontype != 6:
            cutimessage += 'Tahun ini anda diberikan ' + str(total_cuti_tahunan)
            cutimessage += ' hari untuk cuti tahunan, sisa ' + str(sisa_cuti_tahunan) + ' hari.\n'
            if total_cuti_panjang > 0:
                cutimessage += 'Anda juga diberikan ' + str(total_cuti_panjang) + ' hari untuk cuti panjang, sisa ' + \
                               str(sisa_cuti_panjang) + ' hari.\nCuti panjang anda berlaku sejak ' + \
                               str(numpydatetime64_to_datetime(startDate_cuti_panjang)[0]) + ', hingga ' + \
                               str(numpydatetime64_to_datetime(expiredDate_cuti_panjang)[0]) + '\n\n'

        cutimessage += generateClaimsCount(cutitahunan, 'request cuti tahunan', questiontype)

        if total_cuti_panjang > 0:
            cutimessage += '\n' + generateClaimsCount(cutipanjang, 'request cuti panjang', questiontype)

        update_PrevTag('cuti')
        return cutimessage, True

    elif getContinueChat() is True and getPrevTag() == 'cuti':
        cutimessage = ''

        if cutidf.shape[0] == 0:
            return "Anda belum menggunakan jatah cuti anda", False

        if cutitahunan.shape[0] > 0:
            cutimessage += 'Berikut adalah data riwayat cuti tahunan anda:\n\n'
            cutimessage += generateAPRmessage(cutitahunan, 'cuti tahunan', 'leave_date')
        if cutipanjang.shape[0] > 0:
            cutimessage += 'Berikut adalah data riwayat cuti panjang anda:\n\n'
            cutimessage += generateAPRmessage(cutipanjang, 'cuti panjang', 'leave_date')
        return cutimessage, False

def generateSSDataResponse(npk, userinput):
    ssmessage = ''

    ssdf = getdata_ss(npk)

    if getContinueChat() is False:
        questiontype, questionword = getQuestionType(userinput)

        if ssdf.shape[0] == 0:
            ssmessage += 'Anda tidak pernah buat system suggestions.\n', False
        else:
            sscount = len(list(set(ssdf.ss_title)))
            ssmessage += 'Anda telah membuat ' + str(sscount) + ' system suggestions.\n'

        if questiontype == 6:
            return ssmessage, False

        monthkeylist = list(set(ssdf['MonthKey']))

        temp = []
        for monthkey in monthkeylist:
            ss_title = ssdf['ss_title'][ssdf['MonthKey'] == monthkey].iloc[0]
            temp.append([monthkey, ss_title])

        ss_summary = pd.DataFrame(temp, columns=['MonthKey', 'SS Title'])
        ss_summary = ss_summary.sort_values(by='MonthKey')

        for index, row, in ss_summary.iterrows():
            ssmessage += row['MonthKey'] + ' - ' + row['SS Title'] + '\n'

        update_PrevTag('system_suggestion')
        return ssmessage, True

    elif getContinueChat() is True and getPrevTag() == 'system_suggestion':
        update_continueChat(False)
        update_PrevTag(None)

        ssmessage = 'Berikut adalah data riwayat system suggestions buatan anda:\n'

        monthkeylist = list(set(ssdf['MonthKey'].values.tolist()))
        monthkeylist.sort(reverse=True)
        firstmonth = monthkeylist[0]

        for month in monthkeylist:
            tempdf = ssdf[ssdf['MonthKey'] == month]
            finish_df = tempdf[tempdf['status'] == 'finish']
            in_progress_df = tempdf[tempdf['status'] == 'in_progress']

            maxlevel = 0
            minlevel = 0

            if len(finish_df) > 0:
                maxlevel = max(finish_df['assessor_level'].values.tolist())
                print('max finish level:', maxlevel)

                tempdf2 = tempdf[tempdf['assessor_level'] == maxlevel]
                
            if len(in_progress_df) > 0:
                minlevel = min(in_progress_df['assessor_level'].values.tolist())
                print('min in progress level:', minlevel)

            tempdf2 = tempdf[(tempdf['assessor_level'] == maxlevel) | (tempdf['assessor_level'] == minlevel)]
            print(tempdf2)
            
            for index, row in tempdf2.iterrows():
                ssmessage += str(row['MonthKey']) + ' [' + row['status'] + ']\nSS: ' + row['ss_title'] + '\n'
                ssmessage += 'Last a' if row['status'] == 'finish' else 'A'
                ssmessage += 'ssessed by: ' + row['AssessorName'] + ' [' + row['level'] + ']\n' 
                if row['status'] == 'finish':
                    ssmessage += str(row['point']) + ' points [Rp.' + str(row['reward']) + ']\n'
                ssmessage += '\n'
            ssmessage += '\n'

        return ssmessage, False

def generateMedicalPlafonResponse(npk, userinput):
    medicalplafondata = getquick_medicalplafon(npk)
    medicalplafondetaildf = getdata_medicalplafon(npk)
    kunjunganklinikdf = getdata_kunjunganklinik(npk)



    limitmedicalplafon = medicalplafondata['limit_medical_plafon'].values[0]
    currmedicalplafon = medicalplafondata['curr_medical_plafon'].values[0]
    usedvalue = medicalplafondata['used_value'].values[0]
    startdatetime = medicalplafondata['startDt'].values[0]
    expirydatetime = medicalplafondata['endDt'].values[0]

    expirydate, expirytime = numpydatetime64_to_datetime(expirydatetime)



    if getContinueChat() is False:
        breakinput = userinput.split()
        targetmedical = None
        for x in breakinput:
            for y in range(len(medicalplafoninnerwords)):
                if x in medicalplafoninnerwords[y]:
                    targetmedical = y
        print('Target medical:', targetmedical)



        medicalplafonmessage = ''

        questiontype, questionword = getQuestionType(userinput)

        if questiontype == 3:
            if medicalplafondetaildf.shape[0] == 0:
                return generateDataNotFoundResponse(), False
            return 'Anda terakhir claim medical pada tanggal ' + str(medicalplafondetaildf['receipt_date'].values[0]), False
        elif questiontype == 4:
            if medicalplafondetaildf.shape[0] == 0:
                return generateDataNotFoundResponse(), False
            alasanmessage = ''
            userinput = removeQuestionWords(userinput)
            status = getAPRstats(userinput)
            tempdf = medicalplafondetaildf[medicalplafondetaildf['stats'] == status]
            for index, row, in tempdf.iterrows():
                alasanmessage += str(row['receipt_date'].date()) + ' [' + row['stats'] + '] - ' + row['info'] + '\n'

            return alasanmessage, False
        elif questiontype != 6:
            sisamessage = 'Sisa medical plafon anda Rp ' + str(currmedicalplafon) + '.\n'
            medicalplafonmessage += sisamessage
            if targetmedical == 0:
                return sisamessage, False

            if usedvalue > 0:
                usedmessage = 'Medical plafon anda sudah dipakai sebesar Rp ' + str(usedvalue) + '.\n'
            else:
                usedmessage = 'Saldo medical plafon anda belum dipakai.\n'
            if targetmedical == 1:
                return usedmessage, False
            medicalplafonmessage += usedmessage

            limitmessage = 'Limit medical plafon yang diberikan kepada anda sebesar Rp ' + str(limitmedicalplafon) + '.\n'
            if targetmedical == 2:
                return limitmessage, False
            medicalplafonmessage += limitmessage

            expirymessage = 'Medical plafon anda akan berakhir pada hari ' + expirydate + ', pukul ' + expirytime + '.\n'
            if targetmedical == 3:
                return expirymessage, False
            medicalplafonmessage += expirymessage

            medicalplafonmessage += '\n'

        if medicalplafondetaildf.shape[0] > 0:
            medicalplafonmessage += generateClaimsCount(medicalplafondetaildf, 'medical', questiontype)

        if kunjunganklinikdf.shape[0] > 0:
            visitcount = len(set(kunjunganklinikdf['tanggal'].values))
            if visitcount > 0:
                if medicalplafondetaildf.shape[0] > 0:
                    medicalplafonmessage += '\n'
                medicalplafonmessage += 'Anda telah berkunjung ke klinik sebanyak ' + str(visitcount) + ' kali.'

        update_PrevTag('medicalplafon')
        return medicalplafonmessage, True
    elif getContinueChat() is True and getPrevTag() == 'medicalplafon':
        medicalplafonmessage = ''

        if medicalplafondetaildf.shape[0] > 0:
            approvedmedicalclaim = medicalplafondetaildf[medicalplafondetaildf['stats'] == 'A']
            len_approvedmedicalplafon = approvedmedicalclaim.shape[0]

            rejectedmedicalclaim = medicalplafondetaildf[medicalplafondetaildf['stats'] == 'R']
            len_rejectedmedicalplafon = rejectedmedicalclaim.shape[0]

            pendingmedicalclaim = medicalplafondetaildf[medicalplafondetaildf['stats'] == 'P']
            len_pendingmedicalplafon = pendingmedicalclaim.shape[0]

            if len_approvedmedicalplafon > 0:
                medicalplafonmessage += 'Approved medical claim'
                if len_approvedmedicalplafon > 1:
                    medicalplafonmessage += 's'
                medicalplafonmessage += ':\n\n'
                for index, row, in approvedmedicalclaim.iterrows():
                    medicalplafonmessage += str(row['receipt_date'].date()) + \
                                            '\nMedical fee: ' + str(row['medical_fee']) +\
                                            '\nTools fee: ' + str(row['tools_fee']) + \
                                            '\nTotal fee: ' + str(row['total_fee']) + \
                                            '\nClaim Reason: ' + row['info'] + '\n\n'

            if len_rejectedmedicalplafon > 0:
                medicalplafonmessage += 'Rejected medical claim'
                if len_rejectedmedicalplafon > 1:
                    medicalplafonmessage += 's'
                medicalplafonmessage += ':\n'
                for index, row, in rejectedmedicalclaim.iterrows():
                    medicalplafonmessage += str(row['receipt_date'].date()) + '\nApproved by: - ' + \
                                            '\nMedical fee: ' + str(row['medical_fee']) + \
                                            '\nTools fee: ' + str(row['tools_fee']) + \
                                            '\nTotal fee: ' + str(row['total_fee']) + \
                                            '\nClaim Reason: ' + row['info'] + '\n\n'

            if len_pendingmedicalplafon > 0:
                medicalplafonmessage += 'On progress medical claim'
                if len_pendingmedicalplafon > 1:
                    medicalplafonmessage += 's'
                medicalplafonmessage += ':\n'
                for index, row, in pendingmedicalclaim.iterrows():
                    medicalplafonmessage += str(row['receipt_date'].date()) + '\nApproved by: - ' + \
                                            '\nMedical fee: ' + str(row['medical_fee']) + \
                                            '\nTools fee: ' + str(row['tools_fee']) + \
                                            '\nTotal fee: ' + str(row['total_fee']) + \
                                            '\nClaim Reason: ' + row['info'] + '\n\n'

            if medicalplafonmessage == '':
                medicalplafonmessage = generateDataNotFoundResponse()

        if kunjunganklinikdf.shape[0] > 0:
            medicalplafonmessage += 'Berikut adalah data-data kunjungan klinik anda:\n\n'

            visitdates = list(set(kunjunganklinikdf['tanggal'].values))
            visitdates.sort(reverse=True)

            for date in visitdates:
                tempdf = kunjunganklinikdf[kunjunganklinikdf['tanggal'] == date]
                diseaselist = list(set(tempdf['jenis_penyakit'][tempdf['tanggal'] == date].values))
                diseaselist.sort()

                for disease in diseaselist:
                    tempdf2 = tempdf[(tempdf['jenis_penyakit'] == disease) & (tempdf['tanggal'] == date)]
                    tanggal, waktu = numpydatetime64_to_datetime(date)
                    medicalplafonmessage += str(tanggal) + '\nPenyakit: ' + disease + '\nList obat yang dibeli:'
                    for index, row in tempdf2.iterrows():
                        medicalplafonmessage += '\n[Harga: ' + str(row['amount']) + '] - [Jumlah: ' + str(row['qty']) \
                                                + '] - ' + row['nama_obat']
                    medicalplafonmessage += '\n\n'



        return medicalplafonmessage, False

#===================================================================================================

def generateLinks(userinput):
    if 'skta' in userinput:
        tag = 'buat SKTA'
    elif 'supem' in userinput:
        tag = 'buat Supem'
    elif 'overtime' in userinput or 'spl' in userinput or 'lembur' in userinput:
        tag = 'claim Overtime'
    elif 'cuti' in userinput:
        tag = 'claim Cuti'
    elif 'ss' in userinput or 'system_suggestion' in userinput:
        tag = 'buat SS'
    elif 'medical' in userinput:
        tag = 'claim Medical'

    if 'ss' in userinput or 'system_suggestion' in userinput:
        link = "https://wecare.daihatsu.astra.co.id/system-suggestion"
    else:
        link = hrislink

    return '<a href=' + link + ' onclick="window.open(this.href); ' \
                               'return false;">Klik disini untuk ' + tag + '</a>'

def getADMNews():
    ADMmainNewsLink = 'https://wecare.daihatsu.astra.co.id/articles'
    return '<a href=' + ADMmainNewsLink + \
           ' onclick="window.open(this.href); return false;">Klik disini untuk baca berita-berita ADM</a>'

